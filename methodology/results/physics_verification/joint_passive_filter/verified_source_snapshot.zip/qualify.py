from pathlib import Path
import json
import subprocess
import sys
import zipfile
from methodology import airborne_verification, numerical_accuracy, source_fingerprints

output = Path('methodology/results/physics_verification/joint_passive_filter')
original = json.loads((output / 'verification.json').read_text())
sources = sorted(original['source_sha256'])
with zipfile.ZipFile(output / 'verified_source_snapshot.zip', 'x', zipfile.ZIP_DEFLATED) as archive:
    for name in sources:
        archive.write(name, name)
    archive.write(__file__, 'qualify.py')
summary = dict(status='running', scope='Numerical verification of the joint airborne candidate; no controller qualification',
    source_sha256=source_fingerprints(*sources), dependencies=original['dependencies'],
    source_snapshot='verified_source_snapshot.zip', prior_evidence=dict(direct_screen='direct_screen/summary.json',
        simultaneous_extinction_failure='simultaneous_extinction_diagnosis.json', interrupted_sensor_batch='sensor_budget/summary.json'),
    direct_screen_source_difference='The retained screen precedes the simultaneous-extinction correction. That correction executes only at disabled-current events; neither direct screen has disabled channels. Sensor reference Jacobian changes affect only the separate verification calculation.')
path = output / 'qualification.json'
airborne_verification.save_summary(path, summary)
tests = ['methodology.tests.test_joint_airborne', 'methodology.tests.test_sensing.HallFilterTests',
    'methodology.tests.test_motion.CouplingReferenceTests',
    'methodology.tests.test_motion.MotionInterfaceTests.test_variable_benchmark_rejection_restores_energy_and_motion',
    'methodology.tests.test_motion.MotionInterfaceTests.test_spinning_body_matches_newton_euler_gyroscopic_term']
with (output / 'verified_tests.log').open('x') as log:
    result = subprocess.run([sys.executable, '-m', 'unittest', *tests, '-v'], stdout=log, stderr=subprocess.STDOUT)
summary['tests_exit_code'] = result.returncode
airborne_verification.save_summary(path, summary)
if result.returncode:
    summary['status'] = 'tests_failed'
    airborne_verification.save_summary(path, summary)
    raise SystemExit(result.returncode)
summary['tests_passed'] = 20
airborne_verification.save_summary(path, summary)
budget = numerical_accuracy.verify_joint_sensor_budget(output / 'verified_sensor_budget')
summary['sensor_budget'] = budget['status']
summary['status'] = 'checks_passed_pending_review' if budget['status'] == 'completed' else 'sensor_budget_failed'
airborne_verification.save_summary(path, summary)
print(json.dumps(dict(status=summary['status'], tests=summary['tests_passed'], sensor_budget=summary['sensor_budget']), indent=2))
if summary['status'] != 'checks_passed_pending_review':
    raise SystemExit(1)
