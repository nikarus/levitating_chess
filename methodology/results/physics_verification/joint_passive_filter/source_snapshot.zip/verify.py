from pathlib import Path
import json
import shutil
import subprocess
import sys
import zipfile
import numpy
import scipy
import mujoco
from methodology import airborne_verification, joint_airborne, numerical_accuracy, source_fingerprints

output = Path('methodology/results/physics_verification/joint_passive_filter')
output.mkdir(parents=True, exist_ok=False)
shutil.copyfile('/tmp/flying-chess-joint-tests.log', output / 'tests.log')
tracked = subprocess.check_output(['git', 'ls-files', '*.py'], text=True).splitlines()
sources = {path for path in tracked if not path.startswith('methodology/results/')}
sources.update(['methodology/joint_airborne.py', 'methodology/tests/test_joint_airborne.py',
    'methodology/requirements.txt', 'methodology/cad/environment.lock.txt'])
with zipfile.ZipFile(output / 'source_snapshot.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for name in sorted(sources):
        archive.write(name, name)
    archive.write(__file__, 'verify.py')
summary = dict(status='running', scope='Numerical candidate verification; no flight qualification',
    source_sha256=source_fingerprints(*sorted(sources)), tests_passed=18,
    dependencies=dict(python=sys.version, scipy=scipy.__version__, numpy=numpy.__version__, mujoco=mujoco.__version__),
    source_snapshot='source_snapshot.zip')
path = output / 'verification.json'
airborne_verification.save_summary(path, summary)
screen = joint_airborne.screen(output / 'direct_screen')
summary['direct_screen'] = screen['status']
airborne_verification.save_summary(path, summary)
if screen['status'] != 'completed':
    summary['status'] = 'direct_screen_failed'
    airborne_verification.save_summary(path, summary)
    raise SystemExit(1)
budget = numerical_accuracy.verify_joint_sensor_budget(output / 'sensor_budget')
summary['sensor_budget'] = budget['status']
summary['status'] = 'checks_passed_pending_review' if budget['status'] == 'completed' else 'sensor_budget_failed'
airborne_verification.save_summary(path, summary)
print(json.dumps(dict(status=summary['status'], direct_screen=summary['direct_screen'], sensor_budget=summary['sensor_budget']), indent=2))
if summary['status'] != 'checks_passed_pending_review':
    raise SystemExit(1)
