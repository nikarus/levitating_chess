from copy import deepcopy
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock

import numpy as np
from scipy.linalg import expm
from scipy.spatial.transform import Rotation

from model import Fixed, Constants
from methodology import electrical, motion
from methodology.cad import magnetics
from methodology.coupling_verification import VariableCouplingTrial, variable_coupling_solution, variable_energy_residual
from methodology.joint_airborne import JointDynamics, JointAirborneSimulation


class JointDynamicsTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.construction = magnetics.ConstructionModel()
        cls.plant = motion.MotionPlant(cls.construction)

    def setUp(self):
        self.height = self.plant.geometry.center_of_mass_height + (self.plant.geometry.max_flight_gap - self.plant.geometry.gap) / 2
        self.plant.reset(position=np.array([0., 0., self.height]))
        self.drivers = electrical.CoilDrivers(self.construction, tuple(self.plant.array.identities))
        self.matrix = np.zeros((6, len(self.drivers.currents)))
        self.dynamics = JointDynamics(self.plant, self.drivers, 1, lambda plant: self.matrix, lambda plant, currents: np.zeros(1))

    def test_free_fall_and_trial_isolation(self):
        before = self.plant.integration_state().copy()
        initial = self.dynamics.pack(self.plant, np.zeros(1))
        duration = Fixed.airborne_check_duration
        result = self.dynamics.integrate(0., duration, initial)[-1]
        np.testing.assert_array_equal(self.plant.integration_state(), before)
        np.testing.assert_array_equal(self.drivers.currents, 0)
        self.dynamics.commit(self.plant, duration, result.y[:, -1])
        self.assertAlmostEqual(self.plant.data.qpos[2], self.height - Constants.gravity * duration ** 2 / 2,
            delta=Fixed.motion_verification_tolerance)
        self.assertAlmostEqual(self.plant.data.qvel[2], -Constants.gravity * duration, delta=Fixed.motion_verification_tolerance)

    def test_constant_electromechanical_coupling_matches_matrix_exponential(self):
        coupling = self.plant.geometry.weight / Fixed.driver_channel_current
        self.matrix[2, 0] = coupling
        self.drivers.currents[0] = Fixed.driver_channel_current * Fixed.coupling_excitation_fraction
        self.drivers.voltage[0] = self.drivers.resistance * self.drivers.currents[0]
        initial = self.dynamics.pack(self.plant, np.zeros(1))
        duration = Fixed.airborne_check_duration
        generator = np.array([[0, 1, 0, 0], [0, 0, coupling / self.plant.model.body_mass[self.plant.king_id], -Constants.gravity],
            [0, -coupling / self.drivers.inductance, -self.drivers.resistance / self.drivers.inductance,
                self.drivers.voltage[0] / self.drivers.inductance], [0, 0, 0, 0]])
        result = self.dynamics.integrate(0., duration, initial)[-1]
        expected = expm(generator * duration) @ [self.height, 0, self.drivers.currents[0], 1]
        actual = result.y[[2, 9, self.dynamics.current.start], -1]
        np.testing.assert_allclose(actual, expected[:3], atol=Fixed.coupling_reference_tolerance, rtol=Fixed.coupling_relative_tolerance ** 2)

    def test_rotated_principal_spin_matches_analytic_orientation(self):
        rotation = Rotation.from_euler('xyz', Fixed.motion_check_orientation_deg, degrees=True)
        principal = Rotation.from_quat(self.plant.model.body_iquat[self.plant.king_id], scalar_first=True)
        spin = principal.apply([0, 0, Fixed.pose_controller_frequency])
        self.plant.reset(position=np.array([0., 0., self.height]), rotation=rotation, velocity=np.r_[np.zeros(3), spin])
        duration = Fixed.airborne_check_duration
        result = self.dynamics.integrate(0., duration, self.dynamics.pack(self.plant, np.zeros(1)))[-1]
        actual = Rotation.from_quat(result.y[3:7, -1], scalar_first=True)
        expected = rotation * Rotation.from_rotvec(spin * duration)
        self.assertLess((actual * expected.inv()).magnitude(), Fixed.adaptive_angle_tolerance)
        np.testing.assert_allclose(result.y[10:13, -1], spin, atol=Fixed.adaptive_angular_velocity_tolerance, rtol=0)

    def test_hall_filter_dense_output_matches_analytic_ramp(self):
        duration = Fixed.airborne_check_duration
        slope = Fixed.hall_linear_range / duration
        self.dynamics.field_signal = lambda plant, currents: np.array([slope * plant.data.time])
        result = self.dynamics.integrate(0., duration, self.dynamics.pack(self.plant, np.zeros(1)))[-1]
        times = np.linspace(0., duration, Fixed.hall_samples_per_sensor)
        rate = 2 * np.pi * Fixed.hall_sensor_bandwidth
        expected = slope * (times - (1 - np.exp(-rate * times)) / rate)
        np.testing.assert_allclose(result.sol(times)[self.dynamics.hall_filter][0], expected,
            atol=Fixed.adaptive_field_tolerance, rtol=0)

    def test_clamp_extinction_matches_exact_electrical_solution(self):
        self.drivers.currents[0] = Fixed.driver_channel_current * Fixed.coupling_excitation_fraction
        initial_current = self.drivers.currents.copy()
        initial = self.dynamics.pack(self.plant, np.zeros(1))
        duration = Fixed.airborne_check_duration
        segments = self.dynamics.integrate(0., duration, initial, enabled=False)
        voltage = self.drivers.terminal_voltage(False)[0]
        equilibrium = voltage / self.drivers.resistance
        exact = self.drivers.inductance / self.drivers.resistance * np.log((initial_current[0] - equilibrium) / -equilibrium)
        self.assertEqual(len(segments), 2)
        self.assertAlmostEqual(segments[0].t[-1], exact, delta=Fixed.adaptive_clock_tolerance)
        self.assertEqual(segments[-1].y[self.dynamics.current.start, -1], 0.)
        self.assertEqual(self.drivers.currents[0], initial_current[0])

    def test_variable_powered_and_switched_against_independent_reference(self):
        for switched in (False, True):
            trial = VariableCouplingTrial(self.construction, self.plant, switched)
            def matrix(plant):
                truth = plant.truth()
                result = np.zeros((6, len(trial.identities)))
                result[2, 0] = trial.vertical_coupling * (1 + Fixed.coupling_excitation_fraction * (truth['com_position_m'][2] - trial.height) / trial.span)
                result[5, 0] = trial.angular_coupling * np.sin(truth['rotation'].as_rotvec()[2])
                return result
            dynamics = JointDynamics(self.plant, trial.drivers, 1, matrix, lambda plant, currents: np.zeros(1))
            reference = variable_coupling_solution(trial, 'Radau', Fixed.qualification_refinement_factor)
            initial = dynamics.pack(self.plant, np.zeros(1))
            powered = dynamics.integrate(0., trial.switch_time, initial)
            segments = powered
            if switched:
                segments += dynamics.integrate(trial.switch_time, trial.duration, powered[-1].y[:, -1], enabled=False)
            times = np.concatenate([segment.t for segment in segments])
            states = np.concatenate([segment.y.T for segment in segments])
            actual = np.c_[states[:, 2] - trial.height, states[:, 9],
                Rotation.from_quat(states[:, 3:7], scalar_first=True).as_rotvec()[:, 2], states[:, 12],
                states[:, dynamics.current.start], states[:, dynamics.work.stop - 1]]
            expected = reference.sample(times)
            limits = np.array([Fixed.adaptive_position_tolerance, Fixed.adaptive_velocity_tolerance,
                Fixed.adaptive_angle_tolerance, Fixed.adaptive_angular_velocity_tolerance, Fixed.adaptive_current_tolerance])
            self.assertTrue(np.all(np.max(np.abs(actual[:, :5] - expected[:, :5]), axis=0) <= limits))
            self.assertLess(np.max(np.abs(variable_energy_residual(trial, actual))), dynamics.energy_budget)


class JointScheduleTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.construction = magnetics.ConstructionModel()

    def substitute_force(self, simulation):
        matrix = np.zeros((6, len(simulation.identities)))
        simulation.dynamics.force_matrix = lambda plant: matrix
        simulation.controller.nominal_matrix = matrix
        simulation.controller.command = Mock(return_value=dict(accepted=True, required_current_A=0.,
            currents=np.zeros(len(simulation.identities))))

    def test_pending_adc_samples_and_hardware_events_replay_exactly(self):
        original = JointAirborneSimulation(self.construction, Fixed.airborne_check_duration)
        self.substitute_force(original)
        while original.clock <= Fixed.hall_power_settle_time:
            original.advance()
        self.assertGreater(original.pending_scans[0]['sample_count'], 0)
        self.assertEqual(original.delivered_scans, 0)
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'checkpoint.json'
            original.save_checkpoint(path)
            resumed = JointAirborneSimulation(self.construction, Fixed.airborne_check_duration, initialize=False)
            self.substitute_force(resumed)
            resumed.load_checkpoint(path)
            self.assertEqual(original.checkpoint_state(), resumed.checkpoint_state())
            while not original.finished:
                original.advance()
                resumed.advance()
            self.assertEqual(original.checkpoint_state(), resumed.checkpoint_state())
        self.assertIsNone(original.stop_reason)
        self.assertGreater(original.delivered_scans, 0)
        self.assertEqual(original.clock, Fixed.airborne_check_duration)
        self.assertLessEqual(original.accounting['absolute_total_defect_J'], original.dynamics.energy_budget)


if __name__ == '__main__':
    unittest.main()
