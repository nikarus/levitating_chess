import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

import numpy as np

import model
from model import Inputs, Fixed
from methodology import coil_layouts, source_fingerprints
from methodology.electronics import current_loop, power_stage


def absorbed_energy_voltage(capacitance, initial_voltage, energy):
    if capacitance<=0 or initial_voltage<0 or energy<0:
        raise ValueError('Energy absorption requires positive capacitance and nonnegative voltage and energy')
    return float(np.sqrt(initial_voltage**2+2*energy/capacitance))


def required_absorption_capacitance(initial_voltage, maximum_voltage, energy):
    if energy<0 or initial_voltage<0 or maximum_voltage<=initial_voltage:
        raise ValueError('Energy absorption requires a positive voltage headroom')
    return 2*energy/(maximum_voltage**2-initial_voltage**2)


def group_power_envelope(parts):
    counts=Counter(row['mpn'] for row in parts)
    channels=counts['INA181A1IDBVR']
    drivers=counts[Fixed.electronics_integrated_driver[0]]
    converters=counts[Fixed.electronics_acquisition_sar[0]]
    if channels!=Fixed.electronics_acquisition_sar[2] or drivers*Fixed.electronics_integrated_driver[2]!=channels or converters!=1:
        raise ValueError('Supply screen requires the complete reviewed independent-coil group')
    nominal=current_loop.nominal_circuit()
    inductance=nominal['inductance']*max(Fixed.qualification_inductance_factors)
    energy=channels*inductance*Fixed.driver_peak_current**2/2
    capacitors=[row for row in parts if row['model_parameter']=='electronics_channel_bus_capacitance']
    capacitance=sum(float(row['value']) for row in capacitors)
    analog_voltage=Fixed.electronics_analog_supply
    amplifier_current=next(row[3] for row in Fixed.electronics_readout_specs if row[0]=='INA181A1')
    fixed_analog_current=channels*amplifier_current+counts['REF5025IDR']*Fixed.electronics_reference_quiescent_current
    typical_awake,maximum_awake,sleep_current=Fixed.electronics_drv8962_supply_currents
    conversion,standby,power_down=Fixed.electronics_sar_analog_currents
    modes={name:dict(driver_VM_W=drivers*nominal['bus_nominal']*driver_current,
        analog_5V_W=analog_voltage*(fixed_analog_current+converters*adc_current))
        for name,driver_current,adc_current in (
            ('all_awake_converting',maximum_awake,conversion),
            ('drivers_asleep_ADC_standby',sleep_current,standby),
            ('drivers_asleep_ADC_power_down',sleep_current,power_down))}
    for mode in modes.values():
        mode['partial_no_load_W']=sum(mode.values())
    board=power_stage.design.BoardGeometry()
    array=power_stage.prototype_coils.prototype_array(Inputs.cad_coil_layout)
    channel_count=board.motor_area/1e6*coil_layouts.channel_density(array,'independent')
    return dict(channels=channels,driver_packages=drivers,converter_packages=converters,
        operating_bus_V=nominal['bus_nominal'],operating_bus_ceiling_V=nominal['bus_high'],
        inductance_upper_H=inductance,simultaneous_disabled_coil_energy_bound_J=energy,
        local_nominal_motor_capacitance_F=capacitance,
        lossless_bus_voltage_after_disable_from_nominal_V=absorbed_energy_voltage(capacitance,nominal['bus_nominal'],energy),
        minimum_effective_capacitance_from_nominal_F=required_absorption_capacitance(nominal['bus_nominal'],nominal['bus_high'],energy),
        local_nominal_capacitance_passes_operating_envelope=absorbed_energy_voltage(capacitance,nominal['bus_nominal'],energy)<=nominal['bus_high'],
        driver_typical_awake_no_load_W=drivers*nominal['bus_nominal']*typical_awake,
        no_load_modes=modes,area_equivalent_installed_channels=channel_count,
        area_equivalent_whole_board_partial_no_load_W={name:values['partial_no_load_W']*channel_count/channels for name,values in modes.items()},
        wake_waits_s=dict(driver=Fixed.electronics_drv8962_wake_time,driver_cold_start=Fixed.electronics_drv8962_turn_on_time,
            ADC_from_standby=Fixed.electronics_sar_wake_times[0],ADC_from_power_down=Fixed.electronics_sar_wake_times[1]),
        continuous_all_channel_coil_copper_loss_W=channels*nominal['coil_resistance']*Fixed.driver_channel_current**2)


def run(review,output):
    if output.exists():
        raise ValueError('Preserve existing supply evidence')
    schematic=json.loads(review.read_text())
    for filename,digest in schematic['source_sha256'].items():
        if hashlib.sha256(Path(filename).read_bytes()).hexdigest()!=digest:
            raise ValueError(f'Schematic review source changed: {filename}')
    report=dict(status='schematic_based_partial_power_and_inductive_return_envelope',
        **group_power_envelope(schematic['components']),
        source_sha256=source_fingerprints(__file__,model.__file__,current_loop.__file__,power_stage.__file__,
            power_stage.design.__file__,power_stage.prototype_coils.__file__,coil_layouts.__file__),
        input_sha256={str(review):hashlib.sha256(review.read_bytes()).hexdigest()},
        complete_supply_or_thermal_qualification=False,
        sources=['https://www.ti.com/lit/ds/symlink/drv8962.pdf','https://www.ti.com/lit/ds/symlink/ads8698.pdf',
            'https://www.ti.com/lit/ds/symlink/ina181.pdf','https://www.ti.com/lit/ds/symlink/ref50.pdf'],
        limitations=[
            'Worst-case stored coil energy at the existing physical peak and inductance upper sensitivity bound, returned without dissipation or source absorption. Lossless energy conservation bounds this isolated inductive return, not externally supplied mechanical energy.',
            'Local capacitance is nameplate capacitance, before DC bias, tolerance, temperature, ESR, ESL and distribution inductance. The calculation does not qualify a bulk capacitor or clamp circuit.',
            'A capacitor alone cannot keep the bus below its operating ceiling if it starts at that ceiling. An explicit supply headroom and/or absorbing clamp is required; no supply is assumed to sink current.',
            'No-load modes sum specified maximum driver VM, converter AVDD, amplifier and reference supply currents at their stated voltages. MCU, digital I/O, reference output load, watchdog, Hall sensing, other logic, conversion losses and output switching are excluded. These are partial scenarios, not whole-board upper bounds.',
            'All-powered installed-channel scaling is area-equivalent, before edge and module rounding. Selective sleep and wake sequencing are required design functions, not implemented by this inventory calculation.',
            'The all-channel copper-loss value is a continuous group stress envelope at cold resistance, not an actual chess workload. Full-board workload, hot resistance, driver losses, motion regeneration, bus wiring and thermal paths remain unresolved.'])
    output.mkdir(parents=True)
    with ZipFile(output/'sources.zip','x',compression=ZIP_DEFLATED) as archive:
        for name in report['source_sha256']:
            archive.write(name,name)
    (output/'summary.json').write_text(json.dumps(report,indent=Fixed.report_precision)+'\n')
    return report


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--review',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    arguments=parser.parse_args()
    print(json.dumps(run(arguments.review,arguments.output),indent=Fixed.report_precision))
