import argparse
import hashlib
import json
from pathlib import Path
import subprocess
from xml.etree import ElementTree
from zipfile import ZIP_DEFLATED, ZipFile

import pcbnew

import model
from model import Inputs, Fixed
from methodology import prototype_coils, source_fingerprints


def export_review(schematic, footprint_library, executable, output):
    if output.exists():
        raise ValueError('Preserve existing schematic review evidence')
    output.mkdir(parents=True)
    commands = [
        ['sch', 'export', 'netlist', '--format', 'kicadxml', '-o', str(output / 'netlist.xml')],
        ['sch', 'export', 'pdf', '-o', str(output / 'channel.pdf')],
        ['sch', 'export', 'bom', '--fields', 'Reference,Value,MPN,Footprint,${QUANTITY},ModelParameter',
         '--labels', 'References,Value,MPN,Footprint,Quantity,ModelParameter',
         '--group-by', 'MPN,Value,Footprint,ModelParameter', '-o', str(output / 'bom.csv')],
        ['sch', 'erc', '--format', 'json', '-o', str(output / 'erc.json')],
    ]
    logs = []
    for command in commands:
        result = subprocess.run([executable, *command, str(schematic)], capture_output=True, text=True, check=True)
        logs.append(dict(command=command, stdout=result.stdout, stderr=result.stderr))
    (output / 'export_log.json').write_text(json.dumps(logs, indent=Fixed.report_precision) + '\n')
    netlist = ElementTree.parse(output / 'netlist.xml').getroot()
    components = []
    footprint_paths = set()
    for component in netlist.findall('components/comp'):
        fields = {field.attrib['name']: field.text for field in component.findall('fields/field')}
        if not fields.get('MPN'):
            raise ValueError(f"Missing part identity: {component.attrib['ref']}")
        parameter = fields.get('ModelParameter')
        value = component.findtext('value')
        if parameter and float(value) != getattr(Fixed, parameter):
            raise ValueError(f"Stale model-derived component value: {component.attrib['ref']}")
        library, name = component.findtext('footprint').split(':')
        filename = footprint_library / f'{library}.pretty' / f'{name}.kicad_mod'
        footprint_paths.add(filename)
        footprint = pcbnew.FootprintLoad(str(filename.parent), name)
        footprint.BuildCourtyardCaches()
        courtyard = footprint.GetCourtyard(pcbnew.F_CrtYd)
        if courtyard.OutlineCount() != 1 or courtyard.Area() <= 0:
            raise ValueError(f'Footprint requires a single closed front courtyard: {filename}')
        components.append(dict(reference=component.attrib['ref'], mpn=fields['MPN'], value=value,
            model_parameter=parameter, footprint=component.findtext('footprint'),
            courtyard_area_mm2=courtyard.Area() / 1e12))
    _, coil, _ = prototype_coils.prototype_geometry(Inputs.cad_coil_layout)
    pitch_area = (coil.outer_width + Inputs.prototype_coil_spacing) * (coil.outer_length + Inputs.prototype_coil_spacing)
    courtyard_area = sum(part['courtyard_area_mm2'] for part in components)
    erc = json.loads((output / 'erc.json').read_text())
    violations = [violation for sheet in erc['sheets'] for violation in sheet['violations']]
    report = dict(status='draft_channel_incomplete_no_manufacturing_release',
        source_sha256=source_fingerprints(__file__, model.__file__, schematic,
            schematic.with_suffix('.kicad_pro'), schematic.parent / 'fp-lib-table', schematic.parent / 'sym-lib-table',
            prototype_coils.__file__),
        footprint_sha256={str(path.relative_to(footprint_library)): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sorted(footprint_paths)},
        component_count=len(components), components=components,
        placement_bound=dict(courtyard_sum_mm2=courtyard_area, coil_pitch_area_mm2=pitch_area,
            double_sided_area_per_coil_mm2=2 * pitch_area,
            minimum_area_ratio_to_double_sided=courtyard_area / (2 * pitch_area),
            fits_even_before_routing=courtyard_area <= 2 * pitch_area),
        erc=dict(errors=sum(row['severity'] == 'error' for row in violations),
            warnings=sum(row['severity'] == 'warning' for row in violations),
            passed=not violations),
        complete_hardware_baseline=False,
        limitations=[
            'Courtyard sum is an optimistic placement lower bound for this candidate and these footprints; no routing, shared circuit or thermal-spreading area is included.',
            'Both PCB faces are credited as fully usable, despite winding terminations and mechanical constraints.',
            'This area result does not exclude a different integrated driver or denser component selection.',
            'This is a channel draft: power generation/regeneration, ADC, buffered reference, independent overcurrent shutdown, control and interconnect are not implemented.',
            'Power flags mark external supply contracts, not verified supplies. ERC failures are retained, not waived.',
            'No component price, production BOM, thermal pass or hardware equivalence to the averaged simulator is claimed.'])
    with ZipFile(output / 'sources.zip', 'x', compression=ZIP_DEFLATED) as archive:
        for name in report['source_sha256']:
            archive.write(name, name)
        for path in sorted(footprint_paths):
            archive.write(path, str(Path('kicad_footprints') / path.relative_to(footprint_library)))
    (output / 'summary.json').write_text(json.dumps(report, indent=Fixed.report_precision) + '\n')
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Export a KiCad channel review and footprint-area lower bound.')
    parser.add_argument('--schematic', type=Path, required=True)
    parser.add_argument('--footprints', type=Path, required=True)
    parser.add_argument('--kicad-cli', required=True)
    parser.add_argument('--output', type=Path, required=True)
    arguments = parser.parse_args()
    export_review(arguments.schematic, arguments.footprints, arguments.kicad_cli, arguments.output)
