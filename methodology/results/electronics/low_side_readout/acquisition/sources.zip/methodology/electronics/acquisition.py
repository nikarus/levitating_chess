import argparse
import hashlib
import json
import math
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

import numpy as np

import model
from model import Fixed
from methodology import electrical, source_fingerprints
from methodology.electronics import readout


def rc_noise_covariance(cutoff, order, lag):
    if cutoff <= 0 or order < 1 or int(order) != order or np.any(np.asarray(lag) < 0):
        raise ValueError('Positive cutoff, positive integer pole count and nonnegative lags required')
    time_constant = 1 / (2 * np.pi * cutoff)
    normalized_lag = np.asarray(lag) / time_constant
    polynomial = sum(math.comb(order - 1, k) * normalized_lag ** (order - 1 - k)
                     * math.factorial(order + k - 1) / 2 ** (order + k)
                     for k in range(order))
    return np.exp(-normalized_lag) * polynomial / (
        2 * time_constant * math.factorial(order - 1) ** 2)


def acquisition_response(cutoff, order, sample_rate, sample_count, frequency):
    if sample_rate <= 0 or sample_count < 1 or int(sample_count) != sample_count:
        raise ValueError('Positive sample rate and positive integer sample count required')
    return weighted_acquisition_response(cutoff, order, sample_rate, np.ones(sample_count) / sample_count, frequency)


def weighted_acquisition_response(cutoff, order, sample_rate, weights, frequency):
    weights = np.asarray(weights)
    if sample_rate <= 0 or weights.ndim != 1 or not len(weights) or not np.isfinite(weights).all():
        raise ValueError('Finite one-dimensional filter weights and positive sample rate required')
    lags = np.arange(len(weights)) / sample_rate
    covariance = rc_noise_covariance(cutoff, order, lags)
    weight_covariance = np.correlate(weights, weights, mode='full')[len(weights) - 1:]
    enbw = weight_covariance[0] * covariance[0] + 2 * np.dot(weight_covariance[1:], covariance[1:])
    transfer = (1 + 1j * frequency / cutoff) ** -order * np.dot(
        weights, np.exp(-2j * np.pi * frequency * lags))
    return dict(white_noise_ENBW_Hz=float(enbw),
        low_frequency_group_delay_s=order / (2 * np.pi * cutoff) + float(np.dot(weights, lags) / weights.sum()),
        loop_bandwidth_magnitude=float(abs(transfer)),
        loop_bandwidth_phase_deg=float(np.angle(transfer, deg=True)),
        first_to_last_sample_s=float(lags[-1]))


def filter_periodic(samples, cutoff, order, carrier):
    frequencies = np.fft.rfftfreq(len(samples), 1 / (len(samples) * carrier))
    transfer = (1 + 1j * frequencies / cutoff) ** -order
    return np.fft.irfft(np.fft.rfft(samples) * transfer, n=len(samples))


def phase_sample_means(samples, samples_per_carrier):
    if len(samples) % samples_per_carrier:
        raise ValueError('Uniform phase grid must be divisible by samples per carrier')
    return samples.reshape(samples_per_carrier, -1).mean(axis=0)


def current_quantizer(samples, sensitivity, bits):
    voltage = Fixed.electronics_current_reference + samples * sensitivity
    if np.min(voltage) < 0 or np.max(voltage) >= Fixed.electronics_analog_supply:
        raise ValueError('ADC input exceeds its screened full-supply range')
    quantum = Fixed.electronics_analog_supply / 2 ** bits
    codes = np.floor(voltage / quantum)
    return ((codes + .5) * quantum - Fixed.electronics_current_reference) / sensitivity


def load_period(folder, grid_count):
    trace = np.loadtxt(folder / 'transient.dat', skiprows=1)
    readout.validate_vendor_transient(trace)
    period = 1 / Fixed.driver_pwm_frequency
    times = np.linspace((Fixed.electronics_spice_cycles - 1) * period,
                        Fixed.electronics_spice_cycles * period, grid_count, endpoint=False)
    return np.interp(times, trace[:, 0], trace[:, 2])


def simultaneous_adc_screen(candidates, evidence, current_noise_density):
    modulator_rate = Fixed.current_regulator_rate * Fixed.electronics_acquisition_adc_osr
    samples_per_carrier = modulator_rate / Fixed.driver_pwm_frequency
    if not samples_per_carrier.is_integer():
        raise ValueError('Periodic ADC comparison requires an integer modulator-to-carrier ratio')
    weights = np.ones(1)
    for _ in range(Fixed.electronics_acquisition_adc_sinc_order):
        weights = np.convolve(weights, np.ones(Fixed.electronics_acquisition_adc_osr) /
                              Fixed.electronics_acquisition_adc_osr)
    sensitivity = evidence['mean_signal_scale_V_per_A']
    price_quantity, price, url = Fixed.electronics_acquisition_adc_price
    channel_count = evidence['amplifier_cost']['area_equivalent_channels']
    frame_bits = Fixed.electronics_acquisition_adc_resolution * Fixed.electronics_acquisition_adc_frame_words
    frame_time = frame_bits / Fixed.electronics_acquisition_adc_max_sclk
    amplifier_price = evidence['amplifier_cost']['price_scenarios'][0]['unit_USD']
    variants = []
    for candidate in candidates:
        if candidate['samples_per_carrier'] != samples_per_carrier:
            continue
        response = weighted_acquisition_response(candidate['cutoff_per_pole_Hz'], candidate['poles'],
            modulator_rate, weights, Fixed.current_loop_bandwidth)
        amplifier_noise = current_noise_density * np.sqrt(response['white_noise_ENBW_Hz'])
        adc_noise = Fixed.electronics_acquisition_adc_noise / sensitivity
        remaining_variance = Fixed.current_feedback_noise ** 2 - amplifier_noise ** 2 - adc_noise ** 2
        variants.append(dict(cutoff_per_pole_Hz=candidate['cutoff_per_pole_Hz'], poles=candidate['poles'],
            **response, readout_delay_lower_estimate_s=response['low_frequency_group_delay_s'] + frame_time,
            phase_including_full_frame_at_loop_bandwidth_deg=response['loop_bandwidth_phase_deg'] -
                360 * Fixed.current_loop_bandwidth * frame_time,
            amplifier_typical_white_noise_rms_A=float(amplifier_noise),
            ADC_typical_noise_reference_A=adc_noise,
            combined_typical_noise_estimate_A=float(np.hypot(amplifier_noise, adc_noise)),
            remaining_independent_noise_estimate_A=float(np.sqrt(max(0., remaining_variance))),
            max_differential_ADC_input_V=max(row['filtered_output_deviation_peak_V'] for row in candidate['trials']),
            all_recorded_inputs_inside_differential_range=all(
                row['filtered_output_deviation_peak_V'] < Fixed.electronics_acquisition_adc_reference
                for row in candidate['trials']),
            acquisition_numerical_refinement_pass=candidate['acquisition_numerical_refinement_pass'],
            max_phase_residue_from_carrier_mean_A=max(
                row['max_phase_residue_from_carrier_mean_A'] for row in candidate['trials']),
            max_error_after_ideal_dc_correction_A=max(
                row['max_error_after_ideal_dc_correction_A'] for row in candidate['trials'])))
    if not variants:
        raise ValueError('No recorded sampling candidate matches the ADC modulator schedule')
    return dict(part=Fixed.electronics_acquisition_adc,
        datasheet='https://www.ti.com/lit/ds/symlink/ads131m08.pdf',
        channels=Fixed.electronics_acquisition_adc_channels, output_rate_Hz=Fixed.current_regulator_rate,
        modulator_rate_Hz=modulator_rate,
        proposed_external_clock_Hz=modulator_rate * Fixed.electronics_acquisition_adc_clock_divisor,
        noise_table_external_clock_Hz=Fixed.electronics_acquisition_adc_nominal_clock,
        nominal_current_code_quantum_A=2 * Fixed.electronics_acquisition_adc_reference /
            2 ** Fixed.electronics_acquisition_adc_resolution / sensitivity,
        proposed_zero_bias_V=Fixed.electronics_acquisition_adc_supply / 2,
        startup_resynchronization_settling_s=Fixed.electronics_acquisition_adc_startup_clocks /
            (modulator_rate * Fixed.electronics_acquisition_adc_clock_divisor),
        default_frame_bits=frame_bits, full_frame_transfer_lower_bound_s=frame_time,
        continuous_serial_payload_per_chip_bits_per_s=frame_bits * Fixed.current_regulator_rate,
        board_aggregate_raw_payload_bits_per_s=channel_count / Fixed.electronics_acquisition_adc_channels *
            frame_bits * Fixed.current_regulator_rate,
        price_observation=dict(date='2026-10-20', quantity=price_quantity, chip_USD=price, source=url),
        ADC_only_USD_per_coil=price / Fixed.electronics_acquisition_adc_channels,
        amplifier_and_ADC_only_USD_per_coil=amplifier_price + price / Fixed.electronics_acquisition_adc_channels,
        amplifier_and_ADC_only_USD_per_board=channel_count * (
            amplifier_price + price / Fixed.electronics_acquisition_adc_channels),
        two_amplifiers_two_simultaneous_ADC_inputs_only_USD_per_coil=2 * (
            amplifier_price + price / Fixed.electronics_acquisition_adc_channels),
        variants=variants,
        limitations=[
            'This is a component comparison, not a selected implementation or complete BOM. Shunts, filters/buffers, reference-bias distribution, decoupling, clocks, supplies, local processors, interconnect, PCB and assembly remain unpriced.',
            'The two-amplifier cost uses two dedicated simultaneous converter inputs. A switched-input alternative has different settling and switching costs and is not ruled out.',
            'The proposed ADC clock is within the published high-resolution-mode range but differs from the noise-table clock. The listed typical ADC noise is a reference estimate, not guaranteed performance.',
            'The ADC requires a lower zero bias or level translation relative to the executed INA181 traces. Here the signal is only recentered algebraically; this does not verify the new amplifier operating point or ADC loading.',
            'At this synchronized clock, the sinc3 filter averages an integer number of carrier periods. Its periodic result equals the uniform modulator-phase mean; this does not validate changing-current or clock-mismatch behavior.',
            'Only the published steady-state digital filter is modeled. Modulator analog response, clock jitter, additional pipeline delay, startup fast-filter samples and overload recovery are not modeled.',
            'SPI transfer time assumes one dedicated bus at its maximum clock with no CS/setup overhead. Board-wide scheduling, fan-out and control deadlines are unqualified.',
            'Internal reference noise is already represented in the cited ADC noise measurement; the external amplifier-bias reference and its correlation with ADC input subtraction remain separate.',
            'All recorded inputs fit only in the stated periodic cases; startup, faults and unfiltered transients still require range/protection checks.'])


def screen(recording):
    evidence = json.loads((recording / 'summary.json').read_text())
    if evidence['status'] != 'one_amplifier_two_shunt_mean_acquisition_screen_not_qualified':
        raise ValueError('Expected return-pair vendor evidence')
    sensitivity = evidence['mean_signal_scale_V_per_A']
    noise_density = next(row[2] for row in Fixed.electronics_readout_specs if row[0] == 'INA181A1')
    current_noise_density = noise_density / evidence['shunt_ohm']
    cycles_per_update = Fixed.driver_pwm_frequency / Fixed.current_regulator_rate
    if not cycles_per_update.is_integer():
        raise ValueError('This screen requires an integer carrier-to-regulator ratio')
    grid = Fixed.electronics_low_side_spice_steps_per_cycle * Fixed.electronics_acquisition_grid_refinement
    recordings = []
    for index, trial in enumerate(evidence['trials']):
        recordings.append([load_period(recording / f'case_{index}_refinement_{refinement}', grid * density)
                           for refinement, density in ((1, 1), (2, 1), (2, 2))])
    candidates = []
    for cutoff in Fixed.electronics_acquisition_cutoffs:
        for order in Fixed.electronics_acquisition_orders:
            filtered = [[filter_periodic(trace, cutoff, order, Fixed.driver_pwm_frequency)
                         for trace in traces] for traces in recordings]
            for samples_per_carrier in Fixed.electronics_acquisition_samples_per_carrier:
                sample_rate = samples_per_carrier * Fixed.driver_pwm_frequency
                timings = []
                for periods in sorted({1, int(cycles_per_update)}):
                    count = samples_per_carrier * periods
                    response = acquisition_response(cutoff, order, sample_rate, count, Fixed.current_loop_bandwidth)
                    noise = current_noise_density * np.sqrt(response['white_noise_ENBW_Hz'])
                    timings.append(dict(averaged_periods=periods, samples_per_update=count,
                        average_ADC_conversions_per_channel_per_s=count * Fixed.current_regulator_rate,
                        amplifier_typical_white_noise_rms_A=float(noise),
                        remaining_independent_noise_rms_A=float(np.sqrt(max(
                            0., Fixed.current_feedback_noise ** 2 - noise ** 2))),
                        amplifier_alone_exceeds_noise_budget=bool(noise > Fixed.current_feedback_noise),
                        **response))
                rows = []
                for trial, traces in zip(evidence['trials'], filtered):
                    sampled = [phase_sample_means(trace, samples_per_carrier) for trace in traces]
                    refined = sampled[-1]
                    dc_reference = trial['checks'][-1]['carrier_mean_A'] - trial['checks'][-1][
                        'mean_error_after_ideal_dc_correction_A']
                    rows.append(dict(command_V=trial['command_V'], current_A=trial['current_A'],
                        assumed_deadtime_s=trial['assumed_deadtime_s'],
                        phase_grid_count=len(refined),
                        filtered_output_deviation_peak_V=float(np.max(np.abs(traces[-1])) * sensitivity),
                        max_phase_residue_from_carrier_mean_A=float(np.max(np.abs(refined - traces[-1].mean()))),
                        max_error_after_ideal_dc_correction_A=float(np.max(np.abs(refined - dc_reference))),
                        vendor_refinement_max_difference_A=float(np.max(np.abs(sampled[1] - sampled[0]))),
                        resampling_refinement_max_difference_A=float(np.max(np.abs(refined[::2] - sampled[1]))),
                        quantizers=[dict(bits=bits, native_quantum_A=Fixed.electronics_analog_supply / 2 ** bits / sensitivity,
                            max_quantization_shift_A=float(np.max(np.abs(phase_sample_means(
                                current_quantizer(traces[-1], sensitivity, bits), samples_per_carrier) - refined))))
                            for bits in Fixed.electronics_acquisition_adc_bits]))
                candidates.append(dict(cutoff_per_pole_Hz=cutoff, poles=order,
                    samples_per_carrier=samples_per_carrier, ADC_within_burst_sample_rate_Hz=sample_rate,
                    timing_and_typical_noise=timings, trials=rows,
                    acquisition_numerical_refinement_pass=all(
                        max(row['vendor_refinement_max_difference_A'], row['resampling_refinement_max_difference_A'])
                        <= Fixed.electronics_spice_current_tolerance for row in rows)))
    cost = evidence['amplifier_cost']
    price = cost['price_scenarios'][0]['unit_USD']
    return dict(status='periodic_recorded_waveform_acquisition_screen_not_hardware_qualification',
        sensitivity_V_per_A=sensitivity,
        required_current_quantum_A=electrical.current_quantum(),
        current_noise_budget_rms_A=Fixed.current_feedback_noise,
        numerical_discrepancy_limit_A=Fixed.electronics_spice_current_tolerance,
        loop_bandwidth_Hz=Fixed.current_loop_bandwidth,
        candidates=candidates,
        simultaneous_ADC_comparison=simultaneous_adc_screen(candidates, evidence, current_noise_density),
        cost_boundary=dict(area_equivalent_channels=cost['area_equivalent_channels'],
            eliminated_amplifier_USD_per_coil=price,
            eliminated_amplifier_USD_per_board=price * cost['area_equivalent_channels'],
            shared_incremental_cost_USD_per_channel_break_even=price),
        hardware_qualified=False,
        limitations=[
            'Ideal unity-gain buffered RC cascades applied to the last recorded PWM cycle in periodic steady state. No physical RC loading, amplifier feedback, buffer noise, component tolerance or startup is modeled.',
            'Recorded inputs are constant imposed coil currents. Carrier means and delayed filtered measurements are not instantaneous current for regulation or Hall subtraction.',
            'Numerical comparisons cover the filtered acquisition only; the retained raw-waveform refinement failure is not repaired.',
            'All grid phases are screened, not all continuous phases; doubled grids bound observed resampling sensitivity only.',
            'Noise uses a flat typical INA181 input density through the ideal RC filter and exact sampled-average autocovariance. This includes correlation and folding of that white noise, not flicker, reference, ADC, shunt, EMI or model uncertainty.',
            'Repeated identical carrier samples do not reduce deterministic quantization or switching bias; multi-period averaging affects the noise and delay calculation only.',
            'Complementary constant-current pulses are nearly antisymmetric about their mean a half-cycle apart. Even sample counts exploit this symmetry; unequal shunts, edges and changing currents can remove it.',
            'Burst sample spacing and average conversions per update are distinct. Sharing a SAR requires a realizable channel schedule and its additional skew/age, not only enough average throughput.',
            'Quantizers are ideal full-supply bins decoded at their centers. Finer averaged code increments are not claimed as extra effective bits.',
            'Signal transfer estimates assume small-signal baseband through the filter and sampler; time-varying bridge modulation and amplifier dynamics require separate verification.',
            'Group delay excludes conversion, communication, processing, actuation and the amplifier response. No loop phase-margin acceptance criterion has been invented.',
            'The cost boundary is the maximum extra acquisition expense versus an otherwise equivalent two-amplifier chain, not a complete BOM or a qualified two-amplifier alternative.'])


def export(recording, output):
    if output.exists():
        raise ValueError('Preserve existing acquisition evidence')
    result = screen(recording)
    result['source_sha256'] = source_fingerprints(__file__, model.__file__, readout.__file__, electrical.__file__)
    inputs = [recording / 'summary.json', *sorted(recording.glob('case_*/transient.dat'))]
    result['recorded_input_sha256'] = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in inputs}
    output.mkdir(parents=True)
    with ZipFile(output / 'sources.zip', 'x', compression=ZIP_DEFLATED) as archive:
        for filename in result['source_sha256']:
            archive.write(filename, filename)
    (output / 'summary.json').write_text(json.dumps(result, indent=Fixed.report_precision) + '\n')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--recording', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    result = export(args.recording, args.output)
    print(json.dumps(dict(status=result['status'], candidates=len(result['candidates']))))
