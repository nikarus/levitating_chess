import argparse
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

import numpy as np
from scipy.optimize import root

import model
from model import Fixed
from methodology import source_fingerprints
from methodology.electronics import power_stage, readout


def periodic_bridge(case, settings, refinement, initial=None):
    period=1/Fixed.driver_pwm_frequency
    shunt=Fixed.electronics_readout_trial_shunt/2
    scale=np.array([Fixed.driver_peak_current,Fixed.driver_peak_current*shunt,
                    Fixed.driver_peak_current*shunt,case['bus_nominal_V'],case['bus_nominal_V']])
    if initial is None:
        current=settings['requested_current_A']
        initial=np.array([current,-current*shunt,current*shunt,
            -current*(shunt+Fixed.electronics_drv8962_on_resistance),current*(shunt+Fixed.electronics_drv8962_on_resistance)])

    def closure(scaled):
        state=scaled*scale
        solved=power_stage.independent_return_period(case,settings,state,0.,np.array([period]),refinement)
        return (solved['final_state']-state)/scale

    result=root(closure,initial/scale,options=dict(xtol=Fixed.electronics_spice_relative_tolerance,
        eps=Fixed.electronics_spice_relative_tolerance,maxfev=Fixed.electronics_bridge_periodic_evaluations))
    state=result.x*scale
    solved=power_stage.independent_return_period(case,settings,state,0.,np.array([0.,period]),refinement)
    closure_current=np.max(np.abs(solved['final_state']-state)/np.array([1.,shunt,shunt,
        Fixed.electronics_drv8962_on_resistance,Fixed.electronics_drv8962_on_resistance]))
    if not np.isfinite(state).all() or closure_current>Fixed.electronics_spice_current_tolerance:
        raise ValueError(f'Periodic bridge state did not close: {closure_current} A, {result.message}')
    return dict(time=solved['native_time'],states=solved['native_states'],initial=state,
        means=solved['carrier_means_A'],closure_A=float(closure_current),root_success=bool(result.success),
        root_message=str(result.message),root_evaluations=result.nfev)


def amplifier_replay_netlist(plant, refinement):
    period=1/Fixed.driver_pwm_frequency
    stop=Fixed.electronics_readout_startup_cycles*period
    time=np.concatenate([plant['time'][:-1]+cycle*period for cycle in range(Fixed.electronics_readout_startup_cycles)]+[np.array([stop])])
    values=np.concatenate([plant['states'][:-1,1:3] for _ in range(Fixed.electronics_readout_startup_cycles)]+[plant['states'][-1:,1:3]])
    time,indices=np.unique(time,return_index=True)
    values=values[indices]
    sources=[]
    for column,leg in enumerate(('A','B')):
        sources.append(f'Vpgnd{leg} pgnd{leg} 0 PWL(\n'+'\n'.join(f'+ {t:.17g} {v:.17g}' for t,v in zip(time,values[:,column]))+'\n+ )')
    gain=next(row[1] for row in Fixed.electronics_readout_specs if row[0]=='INA181A1')
    sensitivity=gain*Fixed.electronics_readout_trial_shunt/2
    step=period/Fixed.electronics_low_side_spice_steps_per_cycle/refinement
    netlist=f'''Physical shunt waveform replay into unchanged TI INA181; input loading reported separately
.include ina181a1.lib
Vs supply 0 {Fixed.electronics_analog_supply:.17g}
Vref reference 0 {Fixed.electronics_current_reference:.17g}
{chr(10).join(sources)}
Xamp pgndB pgndA supply 0 reference output INA181A1
Rload output 0 {Fixed.electronics_readout_test_load:.17g}
.options {Fixed.electronics_readout_spice_solver} method={Fixed.electronics_readout_spice_method} maxord={Fixed.electronics_readout_spice_order} reltol={Fixed.electronics_readout_spice_relative_tolerance:.17g} abstol={Fixed.electronics_spice_absolute_tolerance:.17g}
.control
set wr_singlescale
set wr_vecnames
set numdgt=17
tran {step:.17g} {stop:.17g} 0 {step:.17g}
let reported_current=(v(output)-{Fixed.electronics_current_reference:.17g})/{sensitivity:.17g}
wrdata transient.dat reported_current i(VpgndA) i(VpgndB)
quit
.endc
.end
'''
    return readout.ramped_readout_supplies(netlist)


def run(output, vendor_model, executable):
    content,executable,fingerprints=readout.prepare_vendor_evidence(output,vendor_model,executable,
        b'.SUBCKT INA181A1 INP INN VCC GND REF OUT')
    extras=source_fingerprints(__file__)
    with ZipFile(output/'sources.zip','a',compression=ZIP_DEFLATED) as archive:
        for name in extras.keys()-fingerprints.keys():
            archive.write(name,name)
    fingerprints.update(extras)
    (output/'ina181a1.lib').write_bytes(content)
    case=next(row for row in power_stage.topology_cases() if row['topology']=='unipolar_full_bridge'
              and row['ripple_pass'] and row['voltage_headroom_pass'])
    period=1/Fixed.driver_pwm_frequency
    rows=[]
    for current in (-Fixed.driver_channel_current,0.,Fixed.driver_channel_current/2,Fixed.driver_channel_current):
        _,settings=power_stage.return_path_netlist(case,current,0.,'pgndA',1,True)
        plants=[]
        checks=[]
        for refinement in (1,2):
            plant=periodic_bridge(case,settings,refinement,plants[0]['initial'] if plants else None)
            plants.append(plant)
            folder=output/f'case_{len(rows)}_refinement_{refinement}'
            readout.execute_spice_case(folder,executable,amplifier_replay_netlist(plant,refinement),
                'ina181a1.lib',Fixed.electronics_readout_spice_compatibility)
            np.savez_compressed(folder/'plant.npz',time=plant['time'],states=plant['states'],initial=plant['initial'])
            trace=np.loadtxt(folder/'transient.dat',skiprows=1)
            stop=Fixed.electronics_readout_startup_cycles*period
            if not np.isfinite(trace).all() or abs(trace[-1,0]-stop)>stop*Fixed.electronics_spice_relative_tolerance:
                raise ValueError('Incomplete amplifier waveform')
            stop=float(trace[-1,0])
            means=readout.interval_means(trace,stop-period,stop)
            previous=readout.interval_means(trace,stop-2*period,stop-period)
            checks.append(dict(refinement=refinement,actual_mean_A=float(plant['means'][0]),
                shunt_mean_A=float(plant['means'][1]),reported_mean_A=float(means[0]),
                reported_error_A=float(means[0]-plant['means'][0]),
                peak_amplifier_input_current_A=float(np.max(np.abs(trace[:,2:]))),
                periodic_closure_A=plant['closure_A'],root_success=plant['root_success'],
                root_evaluations=plant['root_evaluations'],adjacent_reported_mean_difference_A=float(abs(means[0]-previous[0]))))
        delta=max(abs(checks[1][name]-checks[0][name]) for name in ('actual_mean_A','shunt_mean_A','reported_mean_A','reported_error_A'))
        rows.append(dict(settings=settings,checks=checks,numerical_mean_difference_A=delta,
            numerical_mean_pass=delta<=Fixed.electronics_spice_current_tolerance))
        (output/'partial.json').write_text(json.dumps(rows,indent=Fixed.report_precision)+'\n')
        if not rows[-1]['numerical_mean_pass'] or checks[-1]['adjacent_reported_mean_difference_A']>Fixed.electronics_spice_current_tolerance:
            raise ValueError('Coupled circuit mean verification is unresolved')
    report=dict(status='state_space_bridge_and_vendor_amplifier_carrier_mean_verification',
        source_sha256=fingerprints,vendor_sha256=hashlib.sha256(content).hexdigest(),trials=rows,
        hardware_qualified=False,limitations=[
            'Behavioral driver, constant exploratory output capacitance, stiff supply and reference; not a manufacturer driver qualification.',
            'Physical shunt voltages are solved by Radau and replayed through the unchanged TI amplifier model. Input loading is recorded but not fed back to the bridge in this diagnostic.',
            'Mean verification does not qualify raw waveform accuracy, sampled ADC accuracy, noise, calibration, thermal behavior or current-loop stability.'])
    (output/'summary.json').write_text(json.dumps(report,indent=Fixed.report_precision)+'\n')
    (output/'partial.json').unlink()
    return report


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--vendor-model',type=Path,required=True)
    parser.add_argument('--ngspice',required=True)
    args=parser.parse_args()
    run(args.output,args.vendor_model,args.ngspice)
