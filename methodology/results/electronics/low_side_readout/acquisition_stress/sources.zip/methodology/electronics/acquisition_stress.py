import argparse
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

import numpy as np

import model
from model import Fixed
from methodology import source_fingerprints
from methodology.electronics import acquisition, power_stage


def high_gate_average(local_time, step, duty, edge_delay=0.):
    period = 1 / Fixed.driver_pwm_frequency
    rise = (1 - duty) * period / 2 + edge_delay
    fall = rise + duty * period
    edge = Fixed.driver_switching_time
    if np.any(rise < 0) or np.any(fall + edge > period):
        raise ValueError('Finite gate edges must fit within a carrier period')

    def primitive(time):
        return (np.maximum(time - rise, 0.) ** 2 - np.maximum(time - rise - edge, 0.) ** 2
                - np.maximum(time - fall, 0.) ** 2 + np.maximum(time - fall - edge, 0.) ** 2) / (2 * edge)

    return np.clip((primitive(local_time + step) - primitive(local_time)) / step, 0., 1.)


def periodic_delay(samples, delay, frequency):
    frequencies = np.fft.rfftfreq(len(samples), 1 / (len(samples) * frequency))
    return np.fft.irfft(np.fft.rfft(samples) * np.exp(-2j * np.pi * frequencies * delay), n=len(samples))


def causal_burst_average(samples, count, frequency, last_sample_skew=0., quantize=None):
    spacing = len(samples) * frequency / Fixed.driver_pwm_frequency / count
    if not float(spacing).is_integer():
        raise ValueError('Sample spacing must align with the uniform screening grid')
    delayed = periodic_delay(samples, -last_sample_skew, frequency) if last_sample_skew else samples
    if quantize is not None:
        delayed, samples = quantize(delayed), quantize(samples)
    return (delayed + sum(np.roll(samples, int(spacing) * index) for index in range(1, count))) / count


def bridge_waveforms(case, changing, polarity, leg_skew, refinement):
    frequency = Fixed.current_loop_bandwidth if changing else Fixed.driver_pwm_frequency
    carriers = Fixed.driver_pwm_frequency / frequency
    regulator_periods = Fixed.current_regulator_rate / frequency
    if not float(carriers).is_integer() or changing and not float(regulator_periods).is_integer():
        raise ValueError('Periodic test frequencies must align with the carrier and regulator')
    steps = Fixed.electronics_low_side_spice_steps_per_cycle * refinement
    count = int(carriers) * steps
    step = 1 / (Fixed.driver_pwm_frequency * steps)
    time = (np.arange(count) + .5) * step
    update_time = np.floor(np.arange(count) * step * Fixed.current_regulator_rate) / Fixed.current_regulator_rate
    resistance, inductance = case['coil_R_ohm'], case['minimum_coil_L_H']
    command = np.full(count, polarity * Fixed.driver_channel_current * resistance)
    if changing:
        phase = 2 * np.pi * frequency * update_time
        command = Fixed.driver_channel_current * (resistance * np.sin(phase) +
                    inductance * 2 * np.pi * frequency * np.cos(phase))
    if np.max(np.abs(command)) > case['terminal_voltage_limit_V']:
        raise ValueError('Diagnostic exceeds the configured command-voltage bound')
    duty_a, duty_b = power_stage.unipolar_leg_duties(float(command[0]), case['bus_nominal_V'])
    duties_a = np.full(count, duty_a)
    duties_b = np.full(count, duty_b)
    if changing:
        duties_a = (1 + command / case['bus_nominal_V']) / 2
        duties_b = 1 - duties_a
    local_time = np.tile(np.arange(steps) * step, int(carriers))
    high_a = high_gate_average(local_time, step, duties_a)
    high_b = high_gate_average(local_time, step, duties_b, leg_skew)
    voltage = case['bus_nominal_V'] * (high_a - high_b)
    frequencies = np.fft.rfftfreq(count, step)
    current = np.fft.irfft(np.fft.rfft(voltage) / (resistance + 2j * np.pi * frequencies * inductance), n=count)
    if np.max(np.abs(current)) > Fixed.driver_peak_current:
        raise ValueError('Diagnostic exceeds the configured peak-current bound')
    return dict(time=time, current=current, low_a=1-high_a, low_b=1-high_b,
                frequency=frequency, voltage=voltage, command=command)


def perturbations():
    cases = [dict(name='nominal', shunt_error=0., leg_skew_s=0., sample_skew_s=0.)]
    cases.extend(dict(name=f'opposed_shunts_{error:g}', shunt_error=error, leg_skew_s=0., sample_skew_s=0.)
                 for error in Fixed.electronics_acquisition_shunt_mismatch)
    for sign in (-1, 1):
        cases.append(dict(name=f'leg_skew_{sign:+d}', shunt_error=0.,
                          leg_skew_s=sign*Fixed.electronics_acquisition_leg_skew, sample_skew_s=0.))
        cases.extend(dict(name=f'sample_skew_{sign*skew:g}', shunt_error=0., leg_skew_s=0., sample_skew_s=sign*skew)
                     for skew in Fixed.electronics_acquisition_sample_skews)
        cases.append(dict(name=f'combined_{sign:+d}', shunt_error=sign*max(Fixed.electronics_acquisition_shunt_mismatch),
                          leg_skew_s=sign*Fixed.electronics_acquisition_leg_skew,
                          sample_skew_s=sign*max(Fixed.electronics_acquisition_sample_skews)))
    return cases


def screen():
    case = next(row for row in power_stage.topology_cases()
                if row['topology']=='unipolar_full_bridge' and row['ripple_pass'] and row['voltage_headroom_pass'])
    cutoff, order = min(Fixed.electronics_acquisition_cutoffs), min(Fixed.electronics_acquisition_orders)
    gain = next(row[1] for row in Fixed.electronics_readout_specs if row[0]=='INA181A1')
    sensitivity = gain * Fixed.electronics_readout_trial_shunt / 2
    rows, saved = [], {}
    for label, changing, polarity in (('steady_positive', False, 1), ('steady_negative', False, -1),
                                     ('changing_current_and_reversal', True, 1)):
        for perturbation in perturbations():
            previous = {}
            for refinement in (1, 2):
                wave = bridge_waveforms(case, changing, polarity, perturbation['leg_skew_s'], refinement)
                current, frequency = wave['current'], wave['frequency']
                modulation = ((1+perturbation['shunt_error'])*wave['low_a'] +
                              (1-perturbation['shunt_error'])*wave['low_b'])
                signal = acquisition.filter_periodic(acquisition.filter_periodic(current * modulation,
                    Fixed.electronics_ina181_bandwidth, 1, frequency), cutoff, order, frequency)
                reference = acquisition.filter_periodic(acquisition.filter_periodic(current,
                    Fixed.electronics_ina181_bandwidth, 1, frequency), cutoff, order, frequency)
                for samples in Fixed.electronics_acquisition_samples_per_carrier:
                    if samples == 1:
                        continue
                    reported = causal_burst_average(signal, samples, frequency, perturbation['sample_skew_s'])
                    delayed_reference = causal_burst_average(reference, samples, frequency)
                    error = reported - delayed_reference
                    if refinement == 1:
                        previous[samples] = error
                        continue
                    coarse_time = (np.arange(len(error)//2)+.5)*2/(len(error)*frequency)
                    fine_aligned = np.interp(coarse_time, wave['time'], error)
                    difference = float(np.max(np.abs(fine_aligned - previous[samples])))
                    bias = float(error.mean())
                    rows.append(dict(trajectory=label, perturbation=perturbation, samples_per_carrier=samples,
                        peak_current_A=float(np.max(np.abs(current))), peak_command_V=float(np.max(np.abs(wave['command']))),
                        mean_measurement_bias_A=bias, peak_distortion_excluding_matched_filter_delay_A=float(np.max(np.abs(error))),
                        RMS_distortion_excluding_matched_filter_delay_A=float(np.sqrt(np.mean(error**2))),
                        peak_distortion_after_own_mean_removed_A=float(np.max(np.abs(error-bias))),
                        peak_total_error_against_instantaneous_current_A=float(np.max(np.abs(reported-current))),
                        numerical_refinement_difference_A=difference,
                        numerical_refinement_pass=difference<=Fixed.electronics_spice_current_tolerance,
                        quantizers=[dict(bits=bits, maximum_quantization_shift_A=float(np.max(np.abs(
                            causal_burst_average(signal,samples,frequency,perturbation['sample_skew_s'],
                                lambda values: acquisition.current_quantizer(values,sensitivity,bits))-reported))))
                            for bits in Fixed.electronics_acquisition_adc_bits]))
                    if samples == 2 and perturbation['name'] in ('nominal','combined_+1'):
                        key=f"{label}_{perturbation['name']}"
                        saved[key]=np.column_stack((wave['time'],current,reported,delayed_reference))
    return dict(status='ideal_bridge_acquisition_sensitivity_not_vendor_or_hardware_qualification',
        filter_cutoff_Hz=cutoff, filter_order=order, assumed_amplifier_single_pole_Hz=Fixed.electronics_ina181_bandwidth,
        coil_resistance_ohm=case['coil_R_ohm'], coil_inductance_H=case['minimum_coil_L_H'],
        current_motion_frequency_Hz=Fixed.current_loop_bandwidth,
        numerical_limit_A=Fixed.electronics_spice_current_tolerance, trials=rows, hardware_qualified=False,
        limitations=[
            'Ideal finite-edge complementary voltage-source bridge and periodic linear RL solution. No transistor/diode, deadtime, bypass routing, back EMF, mutual coupling, parasitics or thermal effects are modeled.',
            'Changing current uses sampled feed-forward voltage from the existing coil R/L at the current-loop bandwidth. It is an excitation for diagnosis, not a closed-loop current-controller test.',
            'The amplifier is a typical-bandwidth single-pole approximation, not the vendor model. These results can expose a mechanism but cannot qualify INA181 transient accuracy or calibrate away its recorded residual.',
            'Opposing shunt errors and timing offsets are exploratory values, not selected parts or guaranteed production bounds. Combined cases are examples, not exhaustive corner qualification.',
            'Matched filtering and averaging of actual coil current provide the reference for distortion. The separate instantaneous-current comparison includes ordinary delay and must not be called sensor distortion.',
            'All sample phases on the grids are evaluated. No phase is optimized independently for each test. Numerical refinement is separate from physical accuracy.',
            'The ideal quantizer is evaluated on the waveform at displaced sample times before averaging. No claim of extra ENOB, ADC settling, stochastic noise or real converter behavior is made.',
            'Mean removal is diagnostic per trial, not a realizable automatic calibration across changing commands.']), saved


def export(output):
    if output.exists():
        raise ValueError('Preserve existing sensitivity evidence')
    result, traces=screen()
    result['source_sha256']=source_fingerprints(__file__,model.__file__,acquisition.__file__,power_stage.__file__,
        power_stage.design.__file__,power_stage.prototype_coils.__file__,power_stage.qualification.__file__)
    output.mkdir(parents=True)
    with ZipFile(output/'sources.zip','x',compression=ZIP_DEFLATED) as archive:
        for filename in result['source_sha256']:
            archive.write(filename,filename)
    np.savez_compressed(output/'traces.npz',**traces)
    (output/'summary.json').write_text(json.dumps(result,indent=Fixed.report_precision)+'\n')
    return result


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    result=export(args.output)
    print(json.dumps(dict(status=result['status'],trials=len(result['trials']),
        numerical_refinement_pass=all(row['numerical_refinement_pass'] for row in result['trials']))))
