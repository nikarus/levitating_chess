#include "regulator_settings.h"

float deadtime_voltage(float target)
{
    float argument = target / DEADTIME_CURRENT_SCALE;
    float magnitude = argument < 0.0f ? -argument : argument;
    float value;
    if (magnitude >= DEADTIME_DOMAIN) {
        value = 1.0f;
    } else {
        float position = magnitude * DEADTIME_INDEX_SCALE;
        unsigned index = (unsigned)position;
        if (index >= DEADTIME_INTERVALS) index = DEADTIME_INTERVALS - 1u;
        value = deadtime_table[index] + (position - (float)index) *
            (deadtime_table[index + 1u] - deadtime_table[index]);
    }
    return DEADTIME_VOLTAGE * (argument < 0.0f ? -value : value);
}

static unsigned nearest_even(float value)
{
    unsigned integer = (unsigned)value;
    float remainder = value - (float)integer;
    return integer + (remainder > 0.5f || (remainder == 0.5f && (integer & 1u)));
}

void regulate_current(float error, float integral, float target, float target_rate, float *result)
{
    float feedforward = COIL_PATH_RESISTANCE * target + COIL_INDUCTANCE * target_rate;
    feedforward += deadtime_voltage(target);
    float requested = COIL_INDUCTANCE * LOOP_ANGULAR_FREQUENCY * error + integral + feedforward;
    float voltage = requested < -VOLTAGE_LIMIT ? -VOLTAGE_LIMIT : requested;
    voltage = voltage > VOLTAGE_LIMIT ? VOLTAGE_LIMIT : voltage;
    if (voltage == requested || error * requested < 0.0f) {
        integral += COIL_PATH_RESISTANCE * LOOP_ANGULAR_FREQUENCY * INTEGRAL_RATIO * error / REGULATION_RATE;
    }
    float positive = 0.5f * (1.0f + voltage / BUS_VOLTAGE);
    float negative = 0.5f * (1.0f - voltage / BUS_VOLTAGE);
    unsigned positive_compare = nearest_even(positive * PWM_HALF_COUNTS);
    unsigned negative_compare = nearest_even(negative * PWM_HALF_COUNTS);
    result[0] = ((float)positive_compare - (float)negative_compare) * BUS_VOLTAGE / PWM_HALF_COUNTS;
    result[1] = integral;
    result[2] = requested;
}
