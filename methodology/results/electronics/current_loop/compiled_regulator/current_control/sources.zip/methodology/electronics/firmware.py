import argparse
import ctypes
import hashlib
import json
from pathlib import Path
import subprocess

import numpy as np

import model
from model import Fixed
from methodology import source_fingerprints
from methodology.electronics import current_loop,logic,power_stage


def regulator_settings():
    circuit=current_loop.nominal_circuit()
    deadtime=power_stage.deadtime_voltage_drop(circuit['bus_nominal'])
    voltage_budget=circuit['resistance']*Fixed.electronics_spice_current_tolerance
    rounding_bound=8*np.finfo(np.float32).eps*deadtime
    interpolation_budget=voltage_budget/2-rounding_bound
    if interpolation_budget<=0:
        raise ValueError('Single-precision feedforward cannot meet the allocated comparison tolerance')
    domain=float(np.arctanh(1-voltage_budget/(2*deadtime)))
    second_derivative_bound=4/(3*np.sqrt(3))
    intervals=int(np.ceil(domain/np.sqrt(8*interpolation_budget/(deadtime*second_derivative_bound))))
    arguments=np.linspace(0,domain,intervals+1)
    table=np.tanh(arguments).astype(np.float32)
    values=dict(COIL_PATH_RESISTANCE=circuit['resistance'],COIL_INDUCTANCE=circuit['inductance'],
        DEADTIME_VOLTAGE=deadtime,DEADTIME_CURRENT_SCALE=Fixed.electronics_deadtime_compensation_current,
        DEADTIME_DOMAIN=domain,DEADTIME_INDEX_SCALE=intervals/domain,
        LOOP_ANGULAR_FREQUENCY=2*np.pi*Fixed.current_loop_bandwidth,
        VOLTAGE_LIMIT=circuit['voltage_limit'],BUS_VOLTAGE=circuit['bus_nominal'],
        INTEGRAL_RATIO=Fixed.electronics_regulation_integral_gain_ratio,REGULATION_RATE=Fixed.current_regulator_rate,
        PWM_HALF_COUNTS=Fixed.electronics_logic_clock/(2*Fixed.driver_pwm_frequency))
    literal=lambda value:float(np.float32(value)).hex()+'f'
    header=''.join(f'#define {name} {literal(value)}\n' for name,value in values.items())
    header+=f'#define DEADTIME_INTERVALS {intervals}u\n'
    header+='static const float deadtime_table[] = {'+','.join(literal(value) for value in table)+'};\n'
    reference=current_loop.CurrentReference(0.,np.float32)
    schedule=current_loop.acquisition.sar_schedule()
    target_row=reference.transition(schedule['actuation_s'])[0]
    pair_row=(reference.transition(0.)[-2]+reference.transition(schedule['sample_spacing_s'])[-2])/2
    transition=reference.transition(1/Fixed.current_regulator_rate)
    def expression(row):
        terms=[f'{literal(value)} * state[{index}]' for index,value in enumerate(row) if value!=0]
        if not terms:
            return '0.0f'
        return ' + '.join(terms)
    header+='void reference_step(const float *state, float *targets, float *advanced) {\n'
    header+=f'targets[0] = {expression(target_row)};\n'
    header+=f'targets[1] = {literal(reference.rates[0])} * (state[{len(reference.state)-1}] - targets[0]);\n'
    header+=f'targets[2] = {expression(pair_row)};\n'
    header+=''.join(f'advanced[{index}] = {expression(row)};\n' for index,row in enumerate(transition))
    header+='}\n'
    bound=deadtime*second_derivative_bound*(domain/intervals)**2/8+rounding_bound
    return header,dict(table_entries=len(table),table_bytes=table.nbytes,argument_domain=domain,
        interpolation_and_rounding_bound_V=bound,saturated_tail_bound_V=voltage_budget/2,
        comparison_voltage_budget_V=voltage_budget,
        method='Linear interpolation uses max abs(tanh second derivative)=4/(3 sqrt(3)); saturation tail is explicit. Rounding reserves eight float32 relative epsilons times the voltage scale.',
        scope='Feedforward voltage before PWM quantization; not a closed-loop trajectory-equivalence bound')


class CompiledRegulator:
    def __init__(self,library):
        build=json.loads(library.with_name('build.json').read_text())
        for filename,digest in build['source_sha256'].items():
            if hashlib.sha256((Path(model.__file__).parent/filename).read_bytes()).hexdigest()!=digest:
                raise ValueError(f'Compiled regulator source changed: {filename}')
        if hashlib.sha256(library.read_bytes()).hexdigest()!=build['binaries'][library.name]:
            raise ValueError('Compiled regulator binary differs from its build evidence')
        header,_=regulator_settings()
        if library.with_name('regulator_settings.h').read_text()!=header:
            raise ValueError('Compiled regulator settings differ from the active model')
        self.library=ctypes.CDLL(str(library.resolve()))
        self.function=self.library.regulate_current
        self.function.argtypes=[ctypes.c_float]*4+[ctypes.POINTER(ctypes.c_float)]
        self.function.restype=None
        self.nominal=current_loop.nominal_circuit()

    def __call__(self,error,integral,target,target_rate,circuit,digital=False,compensate_deadtime=True):
        if not digital or not compensate_deadtime or circuit!=self.nominal:
            raise ValueError('Compiled regulator requires the generated digital nominal circuit configuration')
        result=(ctypes.c_float*3)()
        self.function(error,integral,target,target_rate,result)
        return tuple(result)



class CompiledReference:
    def __init__(self,initial_current,dtype,library):
        if dtype!=np.float32:
            raise ValueError('Compiled reference requires single-precision state')
        self.state=np.full(len(current_loop.CurrentReference(0.).state),initial_current,dtype=np.float32)
        self.library=library
        self.function=library.reference_step
        self.function.argtypes=[ctypes.POINTER(ctypes.c_float)]*3
        self.function.restype=None
        self.targets=np.zeros(3,dtype=np.float32)
        self.advanced=np.zeros_like(self.state)
        self.sampled=False

    def current_and_rate(self,elapsed):
        if elapsed!=current_loop.acquisition.sar_schedule()['actuation_s']:
            raise ValueError('Compiled reference requires the generated actuation phase')
        self.function(*(array.ctypes.data_as(ctypes.POINTER(ctypes.c_float))
            for array in (self.state,self.targets,self.advanced)))
        self.sampled=True
        return self.targets[0],self.targets[1]

    def paired_reading(self,start):
        if not self.sampled or start!=0:
            raise ValueError('Compiled reference pair must belong to the current regulator sample')
        return self.targets[2]

    def at(self,elapsed):
        if not self.sampled or elapsed!=1/Fixed.current_regulator_rate:
            raise ValueError('Compiled reference advances exactly one sampled regulator interval')
        self.sampled=False
        return self.advanced.copy()


def run(output,host_compiler,arm_compiler):
    if output.exists():
        raise ValueError('Preserve existing compiled-regulator evidence')
    output.mkdir(parents=True)
    source=Path(__file__).with_name('regulator.c')
    header=output/'regulator_settings.h'
    header_text,approximation=regulator_settings()
    header.write_text(header_text)
    library=output/'regulator.so'
    commands=[
        [str(host_compiler),'-O2','-std=c11','-fno-fast-math','-ffp-contract=off','-fPIC','-shared',
         '-I',str(output),str(source),'-o',str(library)],
        [str(arm_compiler),'--target=arm-none-eabi','-mcpu=cortex-m33','-mfpu=fpv5-sp-d16','-mfloat-abi=hard',
         '-O2','-std=c11','-fno-fast-math','-ffp-contract=off','-I',str(output),'-S',str(source),'-o',str(output/'regulator.arm.s')],
        [str(arm_compiler),'--target=arm-none-eabi','-mcpu=cortex-m33','-mfpu=fpv5-sp-d16','-mfloat-abi=hard',
         '-O2','-std=c11','-fno-fast-math','-ffp-contract=off','-I',str(output),'-c',str(source),'-o',str(output/'regulator.arm.o')],
    ]
    logs=[]
    for command in commands:
        result=subprocess.run(command,capture_output=True,text=True,check=True)
        logs.append(dict(command=command,stdout=result.stdout,stderr=result.stderr))
    fingerprints=source_fingerprints(__file__,source,header,model.__file__)
    (output/'build.json').write_text(json.dumps(dict(source_sha256=fingerprints,commands=logs,
        binaries={path.name:hashlib.sha256(path.read_bytes()).hexdigest() for path in (library,output/'regulator.arm.o')},
        toolchains={str(path):subprocess.run([str(path),'--version'],capture_output=True,text=True,check=True).stdout
            for path in (host_compiler,arm_compiler)}),indent=Fixed.report_precision)+'\n')
    backend=CompiledRegulator(library)
    reference_factory=lambda initial,dtype:CompiledReference(initial,dtype,backend.library)
    report=current_loop.run(output/'current_control',digital=True,regulator=backend,reference_factory=reference_factory,extra_sources=tuple(fingerprints))
    result=dict(status='compiled_current_regulation_averaged_screen',passed=report['passed'],
        trial_count=len(report['trials']),feedforward_approximation=approximation,host_execution_verified=True,arm_object_compiled=True,
        worst_case_execution_time_qualified=False,hardware_qualified=False,schedule=logic.controller_schedule(),
        limitations=[
            'Runs C reference filtering and the PI/feedforward/PWM kernel inside the existing averaged plant; acquisition and scheduling remain Python implementations.',
            'The same source compiles for Cortex-M33, but only the host binary is executed here. ARM library linkage, runtime and cycle timing are not established.',
            'The bounded interpolation removes the transcendental library call. Kernel, reference filtering, acquisition and PWM writes still need processor cycle-time verification.',
            'No interrupts, DMA contention, flash stalls or processor faults are simulated by this compilation check.'])
    (output/'summary.json').write_text(json.dumps(result,indent=Fixed.report_precision)+'\n')
    return result


if __name__=='__main__':
    parser=argparse.ArgumentParser(description='Build and screen the embedded current-regulation kernel.')
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--host-compiler',type=Path,required=True)
    parser.add_argument('--arm-compiler',type=Path,required=True)
    args=parser.parse_args()
    print(json.dumps(run(args.output,args.host_compiler,args.arm_compiler)))
