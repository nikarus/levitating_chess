import argparse
import hashlib
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

import numpy as np

import model
from model import Fixed
from methodology import qualification, source_fingerprints
from methodology.electronics import current_loop, logic


def held_voltage_limit_time(current, voltage, resistance, inductance, limit):
    if resistance <= 0 or inductance <= 0 or limit <= 0:
        raise ValueError('Positive RL parameters and current limit are required')
    if abs(current) >= limit:
        return 0.
    equilibrium = voltage / resistance
    if abs(equilibrium) <= limit:
        return np.inf
    boundary = np.copysign(limit, equilibrium)
    return float(-inductance / resistance * np.log((boundary-equilibrium)/(current-equilibrium)))


def frozen_command_trial(trace, configuration, ripple_bound, schedule):
    nominal = current_loop.nominal_circuit()
    resistance = nominal['resistance'] * configuration.get('resistance_factor', 1.)
    inductance = nominal['inductance'] * configuration.get('inductance_factor', 1.)
    period = 1 / Fixed.current_regulator_rate
    actuation = schedule['actuation_s']
    np.testing.assert_allclose(trace[:, 0], (np.arange(len(trace))+1)*period,
        rtol=0., atol=np.finfo(float).eps*trace[-1, 0])
    previous_currents = np.r_[0., trace[:-1, 3]]
    previous_voltages = np.r_[0., trace[:-1, 5]]
    update_currents = qualification.rl_step(previous_currents, previous_voltages, 0., resistance, inductance, actuation)
    reconstructed = qualification.rl_step(update_currents, trace[:, 5], 0., resistance, inductance, period-actuation)
    reconstruction_error = float(np.max(np.abs(reconstructed-trace[:, 3])))
    if reconstruction_error > Fixed.electronics_spice_current_tolerance:
        raise ValueError('Recorded trajectory does not reconstruct with its stated averaged RL circuit')
    next_update_currents = qualification.rl_step(trace[:, 3], trace[:, 5], 0., resistance, inductance, actuation)
    limit = Fixed.driver_peak_current-ripple_bound
    delays = np.array([held_voltage_limit_time(current, voltage, resistance, inductance, limit)
        for current, voltage in zip(next_update_currents, trace[:, 5])])
    finite = np.flatnonzero(np.isfinite(delays))
    if not len(finite):
        return dict(reconstruction_error_A=reconstruction_error, finite_crossing_intervals=0,
            minimum_hold_after_missed_update_s=None)
    index = int(finite[np.argmin(delays[finite])])
    return dict(reconstruction_error_A=reconstruction_error, finite_crossing_intervals=len(finite),
        minimum_hold_after_missed_update_s=float(delays[index]), row=index,
        missed_update_time_s=float(trace[index, 0]+actuation),
        current_at_missed_update_A=float(next_update_currents[index]),
        stale_effective_voltage_V=float(trace[index, 5]), resistance_ohm=resistance, inductance_H=inductance,
        ripple_bound_A=ripple_bound, average_current_limit_A=limit,
        interval_has_following_recorded_update=index+1<len(trace))


def run(recording, output):
    if output.exists():
        raise ValueError('Preserve existing protection evidence')
    report_path = recording/'summary.json'
    trace_path = recording/'traces.npz'
    recorded = json.loads(report_path.read_text())
    if not recorded['passed'] or not recorded['single_precision_regulator_and_integer_PWM']:
        raise ValueError('Use a completed passing digital current-control recording')
    for filename, digest in recorded['source_sha256'].items():
        if hashlib.sha256(Path(filename).read_bytes()).hexdigest() != digest:
            raise ValueError(f'Recorded source no longer matches the diagnostic configuration: {filename}')
    traces = np.load(trace_path)
    trials = []
    for index, row in enumerate(recorded['trials']):
        name = f'case_{index//2}_noise_{int(row["quantization_and_noise"])}'
        trial = frozen_command_trial(traces[name], row['configuration'], row['ripple_bound_A'], recorded['schedule'])
        trials.append(dict(trace=name, configuration=row['configuration'], **trial))
    limiting = min((row for row in trials if row['minimum_hold_after_missed_update_s'] is not None),
        key=lambda row: row['minimum_hold_after_missed_update_s'])
    deadline = limiting['minimum_hold_after_missed_update_s']
    channel_interval = logic.controller_schedule()['carrier_ticks']/Fixed.electronics_logic_clock
    report = dict(status='recorded_averaged_frozen_command_protection_screen',
        source_sha256=source_fingerprints(__file__, model.__file__, qualification.__file__, current_loop.__file__, logic.__file__),
        input_sha256={str(path):hashlib.sha256(path.read_bytes()).hexdigest() for path in (report_path, trace_path)},
        trial_count=len(trials), trials=trials, limiting_case=limiting,
        group_successful_update_interval_s=channel_interval,
        typical_driver_enable_delay_s=Fixed.electronics_drv8962_enable_delay,
        maximum_remaining_detection_and_gating_time_s=deadline-Fixed.electronics_drv8962_enable_delay,
        per_channel_periodic_watchdog_is_fast_enough=deadline>=1/Fixed.current_regulator_rate+Fixed.electronics_drv8962_enable_delay,
        group_periodic_watchdog_has_nominal_timing_room=deadline>=channel_interval+Fixed.electronics_drv8962_enable_delay,
        hardware_protection_qualified=False,
        limitations=[
            'Exact RL continuation of recorded effective averaged voltage with the existing conservative ripple reserve. It is not a resolved switching fault or manufacturer protection model.',
            'A CPU failure may leave the last valid voltage active after its next expected replacement. The minimum is over every recorded held-voltage interval; monotonic RL motion makes the endpoint the shortest remaining crossing time.',
            'The diagnostic covers stale valid commands only. Corrupt PWM, rail faults, shoot-through, frozen high outputs, back-EMF, coupling and pending command corruption require separate protection.',
            'No existing watchdog or circuit is assumed. Heartbeats must be tied to successful validated control updates, not free-running peripherals. A group heartbeat cannot detect one skipped coil unless the complete sequence is validated.',
            'The EN propagation delay is a typical datasheet value, not a guaranteed shutdown bound. Detection, component tolerance, gate delay and commutation still need qualification.',
            'Tested resistance/filter factors are exploratory sensitivities. This screen does not establish exhaustive operating-corner or fault coverage.'])
    output.mkdir(parents=True)
    with ZipFile(output/'sources.zip', 'x', compression=ZIP_DEFLATED) as archive:
        for name in report['source_sha256']:
            archive.write(name, name)
    (output/'summary.json').write_text(json.dumps(report, indent=Fixed.report_precision, allow_nan=False)+'\n')
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--recording', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    arguments = parser.parse_args()
    report = run(arguments.recording, arguments.output)
    print(json.dumps(report['limiting_case'], indent=Fixed.report_precision))
