import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

import numpy as np
from scipy.integrate import solve_ivp

import model
from model import Fixed
from methodology import qualification, source_fingerprints
from methodology.electronics import acquisition, current_loop, power_stage


def coupled_equations(case,settings):
    physical,physical_jacobian=power_stage.return_path_equations(case,settings)
    sensor=acquisition.sensing_filter()
    rates=2*np.pi*np.asarray(sensor['poles_Hz'])
    shunt=Fixed.electronics_readout_trial_shunt/2
    count=5+len(rates)

    def derivative(time,state):
        result=np.empty(count)
        result[:5]=physical(time,state)[:5]
        result[5]=rates[0]*((state[2]-state[1])/shunt-state[5])
        result[6]=rates[1]*(sensor['load_gain']*state[5]+sensor['load_offset_A']-state[6])
        result[7:]=rates[2:]*(state[6:-1]-state[7:])
        return result

    def jacobian(time,state):
        matrix=np.zeros((count,count))
        matrix[:5,:5]=physical_jacobian(time,state)[:5,:5]
        matrix[5,1:3]=rates[0]*np.array([-1.,1.])/shunt
        matrix[5,5]=-rates[0]
        matrix[6,5:7]=rates[1]*np.array([sensor['load_gain'],-1.])
        for index,rate in enumerate(rates[2:],7):
            matrix[index,index-1:index+1]=np.array([rate,-rate])
        return matrix

    return derivative,jacobian


def periodic_initial(recording,refinement):
    evidence=json.loads((recording/'summary.json').read_text())
    currents=np.array([row['checks'][-1]['actual_mean_A'] for row in evidence['trials']])
    index=int(np.argmax(currents))
    trial=evidence['trials'][index]
    if evidence['status']!='state_space_bridge_and_vendor_amplifier_carrier_mean_verification' or not trial['numerical_mean_pass']:
        raise ValueError('A verified positive-current periodic bridge is required')
    path=recording/f'case_{index}_refinement_{refinement}/plant.npz'
    with np.load(path) as saved:
        time=saved['time']
        states=saved['states']
    period=1/Fixed.driver_pwm_frequency
    if abs(time[-1]-period)>period*Fixed.electronics_spice_relative_tolerance:
        raise ValueError('Recorded bridge carrier differs from the simulation carrier')
    grid=Fixed.electronics_low_side_spice_steps_per_cycle*Fixed.electronics_acquisition_grid_refinement*refinement
    samples=np.arange(grid)*period/grid
    signal=np.interp(samples,time,(states[:,2]-states[:,1])/(Fixed.electronics_readout_trial_shunt/2))
    sensor=acquisition.sensing_filter()
    initial=list(states[0,:5])
    for index,pole in enumerate(sensor['poles_Hz']):
        if index==1:
            signal=sensor['load_gain']*signal+sensor['load_offset_A']
        signal=acquisition.filter_periodic(signal,pole,1,Fixed.driver_pwm_frequency)
        initial.append(signal[0])
    return np.asarray(initial),trial['settings'],float(currents.max()),path


def simulate(recording,refinement,output):
    state,settings,initial_current,source=periodic_initial(recording,refinement)
    case=next(row for row in power_stage.topology_cases()
        if row['topology']=='unipolar_full_bridge' and row['ripple_pass'] and row['voltage_headroom_pass'])
    nominal=current_loop.nominal_circuit()
    sensor=acquisition.sensing_filter()
    schedule=acquisition.sar_schedule()
    period=1/Fixed.driver_pwm_frequency
    cycles=Fixed.electronics_regulation_switching_duration/period
    carriers_per_update=Fixed.driver_pwm_frequency/Fixed.current_regulator_rate
    latch_cycles=schedule['pwm_latch_s']/period
    if not all(float(value).is_integer() for value in (cycles,carriers_per_update,latch_cycles)):
        raise ValueError('The switching run must align with carrier and regulator clocks')
    cycles,carriers_per_update,latch_cycles=map(int,(cycles,carriers_per_update,latch_cycles))
    integral=settings['command_V']-current_loop.deadtime_feedforward(initial_current,case['bus_nominal_V'])
    queued={}
    native_time=[np.array([0.])]
    native_states=[state[None,:].copy()]
    events=[]
    rng=np.random.default_rng(Fixed.current_feedback_seed)
    count=len(state)
    tolerance=np.r_[Fixed.electronics_spice_absolute_tolerance,
        np.full(4,Fixed.electronics_bridge_voltage_tolerance),
        np.full(count-5,Fixed.electronics_spice_absolute_tolerance)]/refinement
    stopped=False
    for cycle in range(cycles):
        previous=settings.copy()
        if cycle in queued:
            settings={**settings,'command_V':queued.pop(cycle)}
        equations=coupled_equations(case,settings)
        previous_equations=coupled_equations(case,previous)
        first=state[-1]
        segments=(0.,Fixed.electronics_drv8962_input_delay,schedule['sample_spacing_s'],period)
        for start,stop in zip(segments[:-1],segments[1:]):
            derivative,jacobian=previous_equations if start==0. else equations
            solution=solve_ivp(derivative,(start,stop),state,method='Radau',jac=jacobian,
                rtol=Fixed.electronics_spice_relative_tolerance/refinement,atol=tolerance,
                max_step=period/Fixed.electronics_spice_steps_per_cycle/refinement)
            state=solution.y[:,-1]
            native_time.append(cycle*period+solution.t[1:])
            native_states.append(solution.y[:,1:].T)
            if not solution.success:
                np.savez_compressed(output/f'refinement_{refinement}_failed.npz',time=np.concatenate(native_time),
                    states=np.concatenate(native_states),events=np.asarray(events))
                (output/'failure.json').write_text(json.dumps(dict(refinement=refinement,cycle=cycle,message=solution.message)))
                raise ValueError(solution.message)
            if np.max(np.abs(solution.y[0]))>Fixed.driver_peak_current:
                stopped=True
                break
            if stop==schedule['sample_spacing_s'] and cycle%carriers_per_update==0:
                raw=acquisition.current_quantizer(np.array([first,state[-1]]),sensor['sensitivity_V_per_A'],
                    Fixed.electronics_acquisition_sar[1],Fixed.electronics_acquisition_sar[4])
                reading=(float(raw.mean())-sensor['load_offset_A'])/sensor['load_gain']+rng.normal(0.,Fixed.current_feedback_noise)
                computed=cycle*period+schedule['computation_ready_s']
                target=-Fixed.driver_channel_current+(initial_current+Fixed.driver_channel_current)*np.exp(-2*np.pi*Fixed.setpoint_filter_cutoff*computed)
                voltage,integral,requested=qualification.current_regulator(target-reading,integral,
                    nominal['resistance'],nominal['inductance'],nominal['voltage_limit'],Fixed.electronics_regulation_integral_gain_ratio,
                    current_loop.deadtime_feedforward(reading,case['bus_nominal_V']))
                queued[cycle+latch_cycles]=float(voltage)
                events.append([cycle*period,computed,(cycle+latch_cycles)*period,reading,target,voltage,requested])
        if stopped:
            break
    time=np.concatenate(native_time)
    states=np.concatenate(native_states)
    events=np.asarray(events)
    np.savez_compressed(output/f'refinement_{refinement}.npz',time=time,states=states,events=events)
    window=1/Fixed.current_regulator_rate
    last=time[-1]
    trace=np.column_stack((time,states[:,0]))
    from methodology.electronics.readout import interval_means
    final_mean=float(interval_means(trace,last-window,last)[0]) if last>=window else None
    return dict(refinement=refinement,stopped=stopped,completed_time_s=float(last),
        peak_current_A=float(np.max(np.abs(states[:,0]))),final_regulator_period_mean_A=final_mean,
        initial_mean_A=initial_current,initial_plant_path=str(source),
        initial_plant_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
        controller_samples=len(events),native_points=len(time))


def run(recording,output):
    if output.exists():
        raise ValueError('Preserve existing switching-loop evidence')
    output.mkdir(parents=True)
    fingerprints=source_fingerprints(__file__,model.__file__,qualification.__file__,acquisition.__file__,current_loop.__file__,
        power_stage.__file__,power_stage.design.__file__,power_stage.prototype_coils.__file__)
    with ZipFile(output/'sources.zip','x',compression=ZIP_DEFLATED) as archive:
        for name in fingerprints:
            archive.write(name,name)
    rows=[]
    for refinement in (1,2):
        rows.append(simulate(recording,refinement,output))
        (output/'partial.json').write_text(json.dumps(rows,indent=Fixed.report_precision)+'\n')
        if rows[-1]['stopped']:
            raise ValueError('Physical switching run stopped at the unchanged peak-current limit')
    with np.load(output/'refinement_1.npz') as first,np.load(output/'refinement_2.npz') as second:
        current_difference=float(np.max(np.abs(np.interp(first['time'],second['time'],second['states'][:,0])-first['states'][:,0])))
        sensor_difference=float(np.max(np.abs(np.interp(first['time'],second['time'],second['states'][:,-1])-first['states'][:,-1])))
        feedback_difference=float(np.max(np.abs(first['events'][:,3]-second['events'][:,3])))
    report=dict(status='resolved_switching_bridge_with_sampled_regulator_and_reduced_readout',
        source_sha256=fingerprints,trials=rows,peak_current_refinement_difference_A=current_difference,
        peak_analog_sensor_refinement_difference_A=sensor_difference,peak_sampled_feedback_difference_A=feedback_difference,
        numerical_pass=max(current_difference,sensor_difference)<=Fixed.electronics_spice_current_tolerance,
        hardware_qualified=False,limitations=[
            'Physical bridge circuit and passive output filter are resolved with a stiff integrator and exact derivatives. The amplifier and ADC internal response remain reduced typical-bandwidth models.',
            'Controller receives only quantized, filtered, delayed sensing with the existing noise budget; actual coil current is used only for plant integration and diagnostics.',
            'Initial bridge comes from the verified positive periodic state. Electronic states use the corresponding periodic reduced-model response; the integral starts at its known holding command minus measured-current dead-time compensation.',
            'Dead-time feedforward is based on smoothed measured current and typical timing/diode estimates, with final saturation and anti-windup inside the shared regulator.',
            'Two-point load correction removes the known nominal resistor-divider gain and bias only. Manufacturer-model replay must verify the reduced readout during this reversal.',
            'No amplifier input loading feedback, guaranteed timing/temperature bounds, shared supply dynamics, EMI, back-EMF, mutual coupling or fault lifecycle is qualified.'])
    (output/'summary.json').write_text(json.dumps(report,indent=Fixed.report_precision)+'\n')
    (output/'partial.json').unlink()
    return report


def vendor_replay(recording,output,vendor_model,executable,reuse_coarse=None):
    from scipy.signal import lsim
    from methodology.electronics import bridge_readout,readout

    evidence=json.loads((recording/'summary.json').read_text())
    if evidence['status']!='resolved_switching_bridge_with_sampled_regulator_and_reduced_readout' or not evidence['numerical_pass']:
        raise ValueError('A numerically verified switching reversal is required')
    with ZipFile(recording/'sources.zip') as archive:
        recorded_model=archive.read('model.py')
    if hashlib.sha256(recorded_model).hexdigest()!=evidence['source_sha256']['model.py']:
        raise ValueError('Recorded model source archive differs from its fingerprint')
    def physical_model_tree(content):
        tree=ast.parse(content)
        for node in tree.body:
            if isinstance(node,ast.ClassDef) and node.name=='Fixed':
                node.body=[field for field in node.body if not (isinstance(field,ast.Assign) and any(
                    isinstance(target,ast.Name) and target.id=='electronics_replay_compression_fraction' for target in field.targets))]
        return ast.dump(tree)
    if physical_model_tree(recorded_model)!=physical_model_tree(Path(model.__file__).read_bytes()):
        raise ValueError('Model settings differ from the executed switching reversal; only replay compression may differ')
    content,executable,fingerprints=readout.prepare_vendor_evidence(output,vendor_model,executable,
        b'.SUBCKT INA181A1 INP INN VCC GND REF OUT')
    extras=source_fingerprints(__file__,current_loop.__file__,acquisition.__file__,bridge_readout.__file__)
    with ZipFile(output/'sources.zip','a',compression=ZIP_DEFLATED) as archive:
        for name in extras.keys()-fingerprints.keys():
            archive.write(name,name)
    fingerprints.update(extras)
    (output/'ina181a1.lib').write_bytes(content)
    period=1/Fixed.driver_pwm_frequency
    prefix=Fixed.electronics_acquisition_filter_cycles*period
    inputs={str(recording/'summary.json'):hashlib.sha256((recording/'summary.json').read_bytes()).hexdigest()}
    rows=[]
    results=[]
    for trial in evidence['trials']:
        refinement=trial['refinement']
        initial=Path(trial['initial_plant_path'])
        if hashlib.sha256(initial.read_bytes()).hexdigest()!=trial['initial_plant_sha256']:
            raise ValueError('Initial periodic bridge has changed')
        source=recording/f'refinement_{refinement}.npz'
        inputs[str(source)]=hashlib.sha256(source.read_bytes()).hexdigest()
        inputs[str(initial)]=trial['initial_plant_sha256']
        with np.load(initial) as saved:
            initial_time,initial_values=bridge_readout.compact_piecewise_linear(saved['time'],saved['states'][:,1:3],
                bridge_readout.replay_voltage_tolerance(refinement))
        with np.load(source) as saved:
            switch_time,switch_states,events=saved['time'],saved['states'],saved['events']
        switch_time,indices=np.unique(switch_time,return_index=True)
        switch_states=switch_states[indices]
        compact_time,compact_values=bridge_readout.compact_piecewise_linear(switch_time,switch_states[:,1:3],
            bridge_readout.replay_voltage_tolerance(refinement))
        time=np.concatenate([initial_time[:-1]+index*period for index in range(Fixed.electronics_acquisition_filter_cycles)]+[prefix+compact_time])
        values=np.concatenate([initial_values[:-1] for _ in range(Fixed.electronics_acquisition_filter_cycles)]+[compact_values])
        time,indices=np.unique(time,return_index=True)
        values=values[indices]
        folder=output/f'case_0_refinement_{refinement}'
        netlist=bridge_readout.amplifier_waveform_netlist(time,values,refinement,True)
        reused_case=None
        if reuse_coarse is not None and refinement==1:
            reused_case=reuse_coarse/'case_0_refinement_1'
            if (reused_case/'test.cir').read_text()!=netlist or (reuse_coarse/'ina181a1.lib').read_bytes()!=content:
                raise ValueError('Reused replay circuit or manufacturer model differs')
            prior=json.loads((reuse_coarse/'partial.json').read_text())
            if not any(row['refinement']==1 for row in prior):
                raise ValueError('Requested coarse replay was not completed')
            folder.mkdir()
            for name in ('test.cir','ngspice.log','transient.dat','.spiceinit'):
                source_path=reused_case/name
                inputs[str(source_path)]=hashlib.sha256(source_path.read_bytes()).hexdigest()
                os.link(source_path,folder/name)
            inputs[str(reuse_coarse/'sources.zip')]=hashlib.sha256((reuse_coarse/'sources.zip').read_bytes()).hexdigest()
            (folder/'ina181a1.lib').symlink_to('../ina181a1.lib')
        else:
            readout.execute_spice_case(folder,executable,netlist,'ina181a1.lib',Fixed.electronics_readout_spice_compatibility,
                timeout=Fixed.electronics_spice_case_timeout*time[-1]/prefix*refinement)
        trace=np.loadtxt(folder/'transient.dat',skiprows=1)
        if not np.isfinite(trace).all() or abs(trace[-1,0]-time[-1])>period*Fixed.electronics_spice_relative_tolerance:
            raise ValueError('Incomplete transient manufacturer replay')
        count=int(round(time[-1]/period*Fixed.electronics_low_side_spice_steps_per_cycle*refinement))
        uniform=np.linspace(0.,time[-1],count+1)
        signal=np.interp(uniform,trace[:,0],trace[:,1])
        pole=2*np.pi*acquisition.sar_filter_pole()
        if Fixed.electronics_acquisition_sar_filter_order!=2:
            raise ValueError('Transient SAR screen requires the specified two-pole candidate')
        _,filtered,_=lsim(([pole*pole],[1.,2*pole,pole*pole]),signal,uniform)
        selected=uniform>=prefix
        motion_time=uniform[selected]-prefix
        measured=filtered[selected]
        reduced=np.interp(motion_time,switch_time,switch_states[:,-1])
        actual=np.interp(motion_time,switch_time,switch_states[:,0])
        sensor=acquisition.sensing_filter()
        difference=(measured-reduced)/sensor['load_gain']
        allowance=Fixed.current_sense_offset_residual/Fixed.current_sense_resistance+Fixed.current_feedback_gain_bound*np.abs(actual)
        pair_time=np.column_stack((events[:,0],events[:,0]+acquisition.sar_schedule()['sample_spacing_s']))
        pairs=np.interp(prefix+pair_time,uniform,filtered)
        quantized=acquisition.current_quantizer(pairs,sensor['sensitivity_V_per_A'],Fixed.electronics_acquisition_sar[1],Fixed.electronics_acquisition_sar[4])
        feedback=(quantized.mean(axis=1)-sensor['load_offset_A'])/sensor['load_gain']
        noise=np.random.default_rng(Fixed.current_feedback_seed).normal(0.,Fixed.current_feedback_noise,len(events))
        feedback_difference=feedback+noise-events[:,3]
        np.savez_compressed(folder/'comparison.npz',time=motion_time,actual_current=actual,
            vendor_readout=measured,reduced_readout=reduced,sample_time=events[:,0],vendor_feedback=feedback+noise,
            original_feedback=events[:,3])
        rows.append(dict(refinement=refinement,reused_case_from=str(reused_case) if reused_case is not None else None,
            replay_voltage_error_bound_V=bridge_readout.replay_voltage_tolerance(refinement),
            peak_reduced_model_discrepancy_A=float(np.max(np.abs(difference))),
            rms_deterministic_discrepancy_A=float(np.sqrt(np.mean(difference**2))),
            peak_feedback_discrepancy_A=float(np.max(np.abs(feedback_difference))),
            within_existing_gain_offset_envelope=bool(np.all(np.abs(difference)<=allowance)),
            peak_input_loading_A=float(np.max(np.abs(trace[:,2:])))))
        results.append((motion_time,measured))
        (output/'partial.json').write_text(json.dumps(rows,indent=Fixed.report_precision)+'\n')
    numerical=float(np.max(np.abs(np.interp(results[0][0],results[1][0],results[1][1])-results[0][1])))
    report=dict(status='manufacturer_amplifier_replay_of_resolved_switching_reversal',source_sha256=fingerprints,
        recorded_input_sha256=inputs,vendor_sha256=hashlib.sha256(content).hexdigest(),trials=rows,
        peak_numerical_discrepancy_A=numerical,numerical_pass=numerical<=Fixed.electronics_spice_current_tolerance,
        hardware_qualified=False,limitations=[
            'Exact recorded bridge voltages drive the unchanged TI amplifier and physical output filter; converter internal dynamics remain the same typical two-pole approximation.',
            'The replay compares the reduced sensor model during one closed-loop reversal. It does not feed the manufacturer output back into a new bridge trajectory.',
            'The existing gain/offset envelope is checked without changing it. Agreement within that envelope does not establish an error allocation for every remaining component.',
            'RMS discrepancy is deterministic model error, not random noise. Input loading is measured but not coupled back; supply/reference noise, ADC INL/DNL and temperature remain unqualified.'])
    (output/'summary.json').write_text(json.dumps(report,indent=Fixed.report_precision)+'\n')
    (output/'partial.json').unlink()
    return report


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--recording',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--vendor-model',type=Path)
    parser.add_argument('--ngspice',default='ngspice')
    parser.add_argument('--reuse-coarse-replay',type=Path)
    args=parser.parse_args()
    if args.reuse_coarse_replay is not None and args.vendor_model is None:
        parser.error('Coarse replay reuse requires the vendor replay mode')
    result=vendor_replay(args.recording,args.output,args.vendor_model,args.ngspice,args.reuse_coarse_replay) if args.vendor_model else run(args.recording,args.output)
    print(json.dumps(dict(numerical_pass=result['numerical_pass'],trials=result['trials'])))
