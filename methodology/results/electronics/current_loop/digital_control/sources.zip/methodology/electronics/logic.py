import numpy as np

from model import Fixed, Constants
from methodology.electronics import acquisition


def controller_schedule():
    clock=Fixed.electronics_logic_clock
    schedule=acquisition.sar_schedule()
    clocks_per_bit=clock/Fixed.electronics_acquisition_sar_serial_clock
    carrier_ticks=clock/Fixed.driver_pwm_frequency
    regulator_ticks=clock/Fixed.current_regulator_rate
    if clock>Fixed.electronics_logic_clock_max or not all(float(value).is_integer() for value in
            (clocks_per_bit,carrier_ticks/2,regulator_ticks)):
        raise ValueError('Controller clocks require integer phase-correct PWM and serial timing within the rated clock')
    guard_ticks=int(np.ceil(clock*Fixed.electronics_acquisition_sar_frame_guard))
    frame_ticks=int(clocks_per_bit*Fixed.electronics_acquisition_sar_frame_bits+guard_ticks)
    sample_ticks=int(carrier_ticks/Fixed.electronics_regulation_samples_per_carrier)
    conversion_ticks=int(np.ceil(clock/Fixed.electronics_acquisition_sar[3]))
    compute_ticks=int(np.ceil(clock*Fixed.electronics_regulation_compute_time))
    if max(frame_ticks,conversion_ticks)>sample_ticks:
        raise ValueError('Integer-clock acquisition cannot finish before the next sample')
    result_ticks=sample_ticks+frame_ticks
    latch_ticks=int(np.ceil((result_ticks+compute_ticks)/carrier_ticks)*carrier_ticks)
    if latch_ticks/clock!=schedule['pwm_latch_s']:
        raise ValueError('Realizable clock schedule changes the already screened actuation phase')
    channels=Fixed.electronics_acquisition_sar[2]
    if channels*carrier_ticks>regulator_ticks or compute_ticks>carrier_ticks:
        raise ValueError('Acquisition or compute jobs overlap the next channel interval')
    return dict(status='integer_clock_controller_schedule_not_firmware_WCET_qualification',
        clock_Hz=clock,carrier_ticks=int(carrier_ticks),pwm_TOP=int(carrier_ticks/2)-1,
        serial_clock_ticks=int(clocks_per_bit),frame_guard_ticks=guard_ticks,
        frame_ticks=frame_ticks,conversion_minimum_ticks=conversion_ticks,
        allocated_compute_ticks=compute_ticks,
        maximum_compute_ticks_before_next_job_or_latch=int(min(carrier_ticks,latch_ticks-result_ticks)),
        compute_utilization=channels*compute_ticks/regulator_ticks,
        channels=[dict(channel=index,sample_ticks=[int(index*carrier_ticks),int(index*carrier_ticks+sample_ticks)],
            result_ready_ticks=int(index*carrier_ticks+result_ticks),
            compute_ready_ticks=int(index*carrier_ticks+result_ticks+compute_ticks),
            latch_ticks=int(index*carrier_ticks+latch_ticks)) for index in range(channels)],
        preserves_screened_actuation_phase=True,hardware_qualified=False,
        source='https://datasheets.raspberrypi.com/rp2350/rp2350-datasheet.pdf',
        limitations=[
            'RP2350-family clock and PWM candidate only; board-level clock tolerance, pin assignment, firmware and processor worst-case execution time are not qualified.',
            'Phase-correct TOP and compare latches follow the datasheet; all PWM slices must be started synchronously. A carrier is assigned to each paired channel readout.',
            'The SPI guard is rounded upward to whole system clocks. Conversion, transfer and compute precede the same carrier latch used by the analog control screen.',
            'The allocated compute duration is a design assumption. The maximum cycle count is a scheduling deadline, not evidence that code meets it.',
            'Shared command transport, fault handling, calibration and Hall sensing need separate timing/resource allocations.'])


def sar_manual_command(channel):
    if not isinstance(channel,int) or not 0<=channel<Fixed.electronics_acquisition_sar[2]:
        raise ValueError('Manual ADC channel is outside the selected device')
    return Constants.ads8698_manual_command | channel<<Constants.ads8698_manual_channel_shift


def sar_register_command(address,value,write=True):
    if not 0<address<1<<(Constants.ads8698_command_bits-Constants.ads8698_address_shift-1):
        raise ValueError('Program register address is outside the non-command range')
    if not 0<=value<1<<Constants.ads8698_register_bits:
        raise ValueError('Program register value exceeds its data word')
    return address<<Constants.ads8698_address_shift | int(write)<<Constants.ads8698_write_bit | value


def sar_decode_frame(frame,expected_channel):
    bits=Fixed.electronics_acquisition_sar[1]
    frame_bits=Fixed.electronics_acquisition_sar_frame_bits
    trailing=frame_bits-Constants.ads8698_command_bits-bits-Constants.ads8698_channel_tag_bits
    if trailing<0 or not 0<=frame<1<<frame_bits:
        raise ValueError('Serial frame cannot hold the conversion and channel address')
    code=(frame>>(trailing+Constants.ads8698_channel_tag_bits))&((1<<bits)-1)
    channel=(frame>>trailing)&((1<<Constants.ads8698_channel_tag_bits)-1)
    if frame>>(frame_bits-Constants.ads8698_command_bits) or frame&((1<<trailing)-1) or channel!=expected_channel:
        raise ValueError('Malformed or stale-channel ADC frame; do not update the regulator')
    return code


class SarSerialInterface:
    def __init__(self):
        self.selected_channel=None
        self.registers={Constants.ads8698_feature_register:0,
            **{Constants.ads8698_first_range_register+index:0 for index in range(Fixed.electronics_acquisition_sar[2])}}

    def exchange(self,command,codes):
        if not isinstance(command,int) or not 0<=command<1<<Constants.ads8698_command_bits:
            raise ValueError('Invalid serial command word')
        frame_bits=Fixed.electronics_acquisition_sar_frame_bits
        if not command&(1<<(Constants.ads8698_command_bits-1)):
            address=command>>Constants.ads8698_address_shift
            if address not in self.registers:
                raise ValueError('Program register is outside the implemented acquisition configuration')
            if command&(1<<Constants.ads8698_write_bit):
                self.registers[address]=command&((1<<Constants.ads8698_register_bits)-1)
            return self.registers[address]<<(frame_bits-Constants.ads8698_command_bits-Constants.ads8698_register_bits)
        channel=(command-Constants.ads8698_manual_command)>>Constants.ads8698_manual_channel_shift
        if command!=sar_manual_command(channel):
            raise ValueError('Unsupported ADC operating command')
        if self.registers[Constants.ads8698_feature_register]!=Constants.ads8698_channel_tag_format or any(
                self.registers[Constants.ads8698_first_range_register+index]!=Constants.ads8698_unipolar_range_code
                for index in range(Fixed.electronics_acquisition_sar[2])):
            raise ValueError('ADC range and tagged-output configuration must be verified before acquisition')
        bits=Fixed.electronics_acquisition_sar[1]
        codes=np.asarray(codes)
        if codes.shape!=(Fixed.electronics_acquisition_sar[2],) or not np.issubdtype(codes.dtype,np.integer) or np.any(codes<0) or np.any(codes>=1<<bits):
            raise ValueError('Converter input must provide one valid code per physical channel')
        previous=self.selected_channel
        self.selected_channel=channel
        if previous is None:
            return None
        trailing=frame_bits-Constants.ads8698_command_bits-bits-Constants.ads8698_channel_tag_bits
        if trailing<0:
            raise ValueError('Configured frame truncates the ADC channel tag')
        return (int(codes[previous])<<Constants.ads8698_channel_tag_bits | previous)<<trailing


def sar_pio_program():
    schedule=controller_schedule()
    bit_ticks=schedule['serial_clock_ticks']
    frame_bits=Fixed.electronics_acquisition_sar_frame_bits
    side_count=len(('SCLK','CS'))
    max_delay=(1<<(Constants.rp2350_pio_delay_side_bits-side_count))-1
    immediate_max=(1<<Constants.rp2350_pio_immediate_bits)-1
    half=bit_ticks//2
    if bit_ticks%2 or not 3<=half<=max_delay+1 or frame_bits%2 or not 0<=frame_bits//2-1<=immediate_max:
        raise ValueError('Serial format does not fit the two-bit PIO loop and instruction delays')
    used_ticks=1+frame_bits*bit_ticks+2
    idle_ticks=schedule['carrier_ticks']//Fixed.electronics_regulation_samples_per_carrier-used_ticks
    idle=None
    for stride in range(1,max_delay+2):
        iterations=min(immediate_max+1,(idle_ticks-1)//stride)
        setup=idle_ticks-iterations*stride
        if iterations>0 and 1<=setup<=max_delay+1:
            idle=(iterations,setup,stride)
            break
    if idle is None:
        raise ValueError('Inter-conversion delay does not fit the PIO loop')
    iterations,setup,stride=idle
    lines=['.program flying_chess_acquisition',f'.side_set {side_count}', '.wrap_target',
        f'set x, {frame_bits//2-1} side 0','bits:',
        f'out pins, 1 side 1 [{half-1}]',f'nop side 0 [{half-3}]','in pins, 1 side 0','nop side 0',
        f'out pins, 1 side 1 [{half-1}]',f'nop side 0 [{half-3}]','in pins, 1 side 0','jmp x-- bits side 0',
        'push block side 2','pull block side 2',f'set y, {iterations-1} side 2 [{setup-1}]',
        'idle:',f'jmp y-- idle side 2 [{stride-1}]','.wrap']
    clock=Fixed.electronics_logic_clock
    falling=1+half+np.arange(frame_bits)*bit_ticks
    cs_high=1+frame_bits*bit_ticks
    next_cs=used_ticks+idle_ticks
    available=np.array([falling[0],cs_high-falling[-1],next_cs-cs_high,half,half,
        falling[Constants.ads8698_command_bits-1],next_cs-falling[Constants.ads8698_command_bits-1]])/clock
    limits=np.array(Constants.ads8698_serial_timing)
    if np.any(available<limits):
        raise ValueError('PIO instruction timing violates converter timing requirements')
    details=dict(instruction_count=sum(not line.startswith('.') and not line.endswith(':') for line in lines),
        first_falling_clock_tick=int(falling[0]),last_falling_clock_tick=int(falling[-1]),
        cs_high_tick=cs_high,next_sample_tick=next_cs,serial_sample_after_clock_assignment_ticks=half-2,
        rx_fifo_complete_tick=cs_high+1,allocated_frame_ticks=schedule['frame_ticks'],
        datasheet_timing_available_s=available.tolist(),datasheet_timing_minimum_s=limits.tolist(),
        configuration=dict(shift_left=True,autopull=False,autopush=True,push_threshold=Constants.rp2350_pio_word_bits,
            initial_osr_command_shift=Constants.rp2350_pio_word_bits-Constants.ads8698_command_bits),
        limitations=[
            'Requires initial OSR preloading, empty ISR, prefetched TX data and continuous RX draining. FIFO stalls invalidate the timing and must inhibit regulation.',
            'Checks instruction-space edge timing, not pad/PCB delay, input synchronizer timing, oscillator tolerance or initial phase synchronization to PWM.',
            'Each complete frame produces one full RX word and one partial word; DMA/CPU must combine them before decoding. No compiled current-regulator execution time is established.'])
    return '\n'.join(lines)+'\n',details


def sar_protocol_screen():
    interface=SarSerialInterface()
    channels=Fixed.electronics_acquisition_sar[2]
    bits=Fixed.electronics_acquisition_sar[1]
    codes=np.rint(np.linspace(0,(1<<bits)-1,channels)).astype(int)
    initialization=[]
    for address,value in [(Constants.ads8698_feature_register,Constants.ads8698_channel_tag_format),
            *[(Constants.ads8698_first_range_register+index,Constants.ads8698_unipolar_range_code) for index in range(channels)]]:
        for write in (True,False):
            command=sar_register_command(address,value if write else 0,write)
            reply=interface.exchange(command,codes)
            expected=value<<(Fixed.electronics_acquisition_sar_frame_bits-Constants.ads8698_command_bits-Constants.ads8698_register_bits)
            if reply!=expected:
                raise ValueError('ADC configuration readback differs from the required value')
            initialization.append(dict(command_hex=f'{command:04X}',reply_hex=f'{reply:010X}',write=write))
    if interface.exchange(sar_manual_command(0),codes) is not None:
        raise ValueError('First manual frame must be discarded during pipeline priming')
    schedule=controller_schedule()
    frames=[]
    for channel in schedule['channels']:
        index=channel['channel']
        for sample,tick in enumerate(channel['sample_ticks']):
            next_channel=index if sample==0 else (index+1)%channels
            command=sar_manual_command(next_channel)
            frame=interface.exchange(command,codes)
            code=sar_decode_frame(frame,index)
            if code!=codes[index]:
                raise ValueError('Received ADC data belongs to another physical input')
            frames.append(dict(sample_tick=tick,channel=index,command_hex=f'{command:04X}',
                received_hex=f'{frame:010X}',code=code,next_selected_channel=next_channel))
            codes=(1<<bits)-1-codes
    wrap=interface.exchange(sar_manual_command(0),codes)
    if sar_decode_frame(wrap,0)!=codes[0]:
        raise ValueError('ADC pipeline failed across the regulator-period boundary')
    return dict(status='ADS8698_manual_pipeline_and_register_protocol_screen',passed=True,
        initialization=initialization,discarded_priming_command_hex=f'{sar_manual_command(0):04X}',frames=frames,
        schedule=schedule,hardware_qualified=False,
        source='https://www.ti.com/lit/ds/symlink/ads8698.pdf',limitations=[
            'Behavioral model of the used manual-conversion and configuration-register subset. Converter analog physics and register electrical timing are not simulated here.',
            'CS falling samples the previously selected channel. The command in that frame chooses the next conversion. Both members of a pair must therefore be scheduled explicitly.',
            'The host captures SDO on falling clocks: the conversion occupies capture clocks 17 through 34 and the channel tag follows. Configuration writes are echoed and independently read back before priming.',
            'Channel tags reject wrong-channel frames but are not a CRC; corrupted conversion bits can remain undetected. Board signal integrity, PIO/DMA code, interrupt handling and execution time remain unqualified.'])


