import argparse
import hashlib
import json
import math
from pathlib import Path
import shutil
import subprocess
from zipfile import ZIP_DEFLATED, ZipFile

import numpy as np

import model
from model import Inputs, Fixed
from methodology import coil_layouts, electrical, source_fingerprints
from methodology.electronics import power_stage


def edge_intervals(mean_voltage, bus_voltage, frequency):
    if not np.isfinite(frequency) or frequency <= 0:
        raise ValueError('Carrier frequency must be positive and finite')
    duties = power_stage.unipolar_leg_duties(mean_voltage, bus_voltage)
    if any(duty in (0., 1.) for duty in duties):
        raise ValueError('Static bridge legs have no periodic edge-spacing measurement')
    return [[duty / frequency, (1 - duty) / frequency] for duty in duties]


def readout_metrics(gain, shunt, input_noise_density, supply_current):
    if not np.isfinite([gain, shunt, input_noise_density, supply_current]).all() or min(
            gain, shunt, input_noise_density, supply_current) <= 0:
        raise ValueError('Readout parameters must be positive and finite')
    sensitivity = gain * shunt
    excursion = Fixed.driver_peak_current * sensitivity
    rails = [Fixed.electronics_current_reference - excursion,
             Fixed.electronics_current_reference + excursion]
    max_enbw = (Fixed.current_feedback_noise * shunt / input_noise_density) ** 2
    return dict(gain_V_per_V=gain, shunt_ohm=shunt, sensitivity_V_per_A=sensitivity,
        nominal_output_range_V=rails,
        ideal_supply_rail_check=0 < rails[0] and rails[1] < Fixed.electronics_analog_supply,
        peak_shunt_loss_W=Fixed.driver_peak_current ** 2 * shunt,
        amplifier_quiescent_upper_W=Fixed.electronics_analog_supply * supply_current,
        full_supply_adc_quantum_A=Fixed.electronics_analog_supply / sensitivity / 2 ** Fixed.current_feedback_bits,
        minimum_ideal_full_supply_adc_bits=math.ceil(math.log2(
            Fixed.electronics_analog_supply / sensitivity / electrical.current_quantum())),
        typical_white_noise_only_max_ENBW_Hz=max_enbw,
        corresponding_single_pole_cutoff_Hz=max_enbw * 2 / np.pi,
        total_readout_qualified=False)


def screen():
    case = next(row for row in power_stage.topology_cases()
                if row['topology'] == 'unipolar_full_bridge' and row['ripple_pass'] and row['voltage_headroom_pass'])
    limit = case['terminal_voltage_limit_V']
    samples = []
    for bus in (case['bus_low_V'], case['bus_nominal_V'], case['bus_high_V']):
        for voltage in np.linspace(-limit, limit, Fixed.electronics_pwm_screen_points):
            intervals = edge_intervals(float(voltage), bus, Fixed.driver_pwm_frequency)
            shortest = min(min(leg) for leg in intervals)
            samples.append(dict(mean_voltage_V=float(voltage), bus_V=bus,
                shortest_common_mode_edge_interval_s=shortest,
                ina241_documented_edge_spacing_met=shortest >= Fixed.electronics_ina241_edge_spacing))
    candidates = []
    for name, gain, noise, current in Fixed.electronics_readout_specs:
        shunts = (Fixed.current_sense_resistance,) if name == 'INA241A1' else (
            Fixed.current_sense_resistance, Fixed.electronics_readout_trial_shunt)
        for shunt in shunts:
            row = dict(name=name, **readout_metrics(gain, shunt, noise, current))
            if name == 'MAX49925':
                row['within_published_gain_error_test_excursion'] = (
                    Fixed.driver_peak_current * gain * shunt <= Fixed.electronics_max49925_gain_test_excursion)
            candidates.append(row)
    return dict(status='analytical_candidate_screen_not_component_qualification',
        required_current_quantum_A=electrical.current_quantum(),
        required_current_noise_rms_A=Fixed.current_feedback_noise,
        pwm_carrier_Hz=Fixed.driver_pwm_frequency,
        shortest_interval_case=min(samples, key=lambda row: row['shortest_common_mode_edge_interval_s']),
        ina241_documented_edge_spacing_covers_command_envelope=all(
            row['ina241_documented_edge_spacing_met'] for row in samples),
        ina241_edge_spacing_voltage_interval_V=[
            -case['bus_low_V'] * (1 - 2 * Fixed.driver_pwm_frequency * Fixed.electronics_ina241_edge_spacing),
            case['bus_low_V'] * (1 - 2 * Fixed.driver_pwm_frequency * Fixed.electronics_ina241_edge_spacing)],
        samples=samples, candidates=candidates,
        datasheets={
            'INA241A1': 'https://www.ti.com/lit/ds/symlink/ina241a.pdf',
            'AD8410A': 'https://www.analog.com/media/en/technical-documentation/data-sheets/ad8410a.pdf',
            'MAX49925': 'https://www.analog.com/media/en/technical-documentation/data-sheets/max49925.pdf'},
        limitations=[
            'Ideal centered unipolar leg timing; finite edge times, dead time, parasitics and movement are not simulated here.',
            'Meeting an edge-spacing condition does not establish sampling accuracy; violating it removes that documented rejection condition, not all amplifier functionality.',
            'Noise uses typical spot input-noise densities as white-noise estimates and assigns the entire existing RMS budget to the amplifier. Flicker, spectral variation, reference, ADC, shunt noise, aliasing and PWM residue require separate analysis.',
            'The illustrative single-pole noise bandwidth is not a selected filter or a verified delay budget.',
            'ADC bits assume a full-supply input span and ideal quantization. A narrower converter range changes this calculation; bits alone do not establish accuracy or noise.',
            'Output checks only screen ideal supply rails; actual output swing, gain/offset variation and ADC loading remain unqualified.',
            'Shunt alternatives are screening cases only; no schematic, controller or flight setting has been changed.',
            'INA241A vendor macro-model omits enhanced PWM rejection. This screen does not execute or qualify manufacturer circuit models.'])


def export_screen(output):
    if output.exists():
        raise ValueError('Preserve existing readout evidence')
    result = screen()
    result['source_sha256'] = source_fingerprints(__file__, model.__file__, electrical.__file__,
        power_stage.__file__, power_stage.design.__file__, power_stage.prototype_coils.__file__,
        power_stage.qualification.__file__)
    output.mkdir(parents=True)
    with ZipFile(output / 'sources.zip', 'x', compression=ZIP_DEFLATED) as archive:
        for filename in result['source_sha256']:
            archive.write(filename, filename)
    (output / 'summary.json').write_text(json.dumps(result, indent=Fixed.report_precision) + '\n')
    return result


def adoption_cost_screen():
    board = power_stage.design.BoardGeometry()
    array = power_stage.prototype_coils.prototype_array(Inputs.cad_coil_layout)
    count = board.motor_area / 1e6 * coil_layouts.channel_density(array, 'independent')
    _, gain, _, quiescent = next(row for row in Fixed.electronics_readout_specs if row[0] == 'AD8410A')
    return dict(
        area_equivalent_channels=count,
        production_boards=Inputs.production_boards,
        area_equivalent_production_amplifiers=count * Inputs.production_boards,
        amplifier_all_powered_quiescent_upper_W=count * Fixed.electronics_analog_supply * quiescent,
        signal_scale_V_per_A=gain * Fixed.electronics_readout_trial_shunt,
        price_observation_date='2026-10-20',
        price_scenarios=[dict(description=name, catalog_quantity=quantity, unit_USD=price,
            amplifier_only_USD_per_board=count * price, source=url)
            for name, quantity, price, url in Fixed.electronics_ad8410_price_observations],
        limitations=[
            'Area times existing independent-channel density, not a finalized edge count or module BOM.',
            'Catalogue prices are extrapolated at their published tiers; no production-volume quotation or guaranteed discount exists.',
            'Only amplifier IC cost is included; shunts, ADC/reference, bridge, control, assembly and cooling are additional.',
            'All-powered quiescent ceiling excludes shunts and dynamic losses; selective power gating and wake-up behaviour are not designed.'])


def vendor_test_netlist(bus, current, command, refinement):
    gain = next(row[1] for row in Fixed.electronics_readout_specs if row[0] == 'AD8410A')
    shunt = Fixed.electronics_readout_trial_shunt
    period = 1 / Fixed.driver_pwm_frequency
    step = period / (Fixed.electronics_spice_steps_per_cycle * refinement)
    stop = Fixed.electronics_spice_cycles * period
    edge = Fixed.driver_switching_time
    duty = power_stage.unipolar_leg_duties(command, bus)[0]
    if min(duty, 1 - duty) * period <= edge:
        raise ValueError('Readout test pulse cannot fit its finite switching edges')
    return f"""AD8410A isolated macromodel check; not a complete coil channel
.include ad8410a.cir
Vs supply 0 {Fixed.electronics_analog_supply:.17g}
Vref reference 0 {Fixed.electronics_current_reference:.17g}
Vcommon common 0 PULSE(0 {bus:.17g} {(1-duty)*period/2:.17g} {edge:.17g} {edge:.17g} {duty*period-edge:.17g} {period:.17g})
Vdiff differential 0 {current*shunt:.17g}
Eplus plus common differential 0 0.5
Eminus minus common differential 0 -0.5
Xamp minus 0 reference output supply reference plus AD8410A
.options reltol={Fixed.electronics_spice_relative_tolerance:.17g} abstol={Fixed.electronics_spice_absolute_tolerance:.17g}
.control
set wr_singlescale
set wr_vecnames
set numdgt=17
dc Vdiff {-Fixed.driver_peak_current*shunt:.17g} {Fixed.driver_peak_current*shunt:.17g} {2*Fixed.driver_peak_current*shunt/(Fixed.electronics_pwm_screen_points-1):.17g}
wrdata dc.dat v(output)
tran {step:.17g} {stop:.17g} 0 {step:.17g}
let reported_current = (v(output)-{Fixed.electronics_current_reference:.17g})/{gain*shunt:.17g}
wrdata transient.dat v(common) reported_current
quit
.endc
.end
"""


def run_vendor_model(output, vendor_model, executable):
    if output.exists():
        raise ValueError('Preserve existing vendor-model evidence')
    content = vendor_model.read_bytes()
    if b'.SUBCKT AD8410A 1 2 3 5 6 7 8' not in content:
        raise ValueError('Expected the AD8410A manufacturer pin interface')
    executable = str(Path(shutil.which(executable)).resolve())
    output.mkdir(parents=True)
    fingerprints = source_fingerprints(__file__, model.__file__, electrical.__file__, power_stage.__file__,
        power_stage.design.__file__, power_stage.prototype_coils.__file__, power_stage.qualification.__file__,
        coil_layouts.__file__)
    with ZipFile(output / 'sources.zip', 'x', compression=ZIP_DEFLATED) as archive:
        for filename in fingerprints:
            archive.write(filename, filename)
    (output / 'ad8410a.cir').write_bytes(content)
    case = next(row for row in power_stage.topology_cases()
                if row['topology'] == 'unipolar_full_bridge' and row['ripple_pass'] and row['voltage_headroom_pass'])
    limit = case['terminal_voltage_limit_V']
    trials = [(command, 0.) for command in (-limit, 0., limit)]
    trials.extend((0., current) for current in (-Fixed.driver_peak_current, Fixed.driver_peak_current))
    rows = []
    for index, (command, current) in enumerate(trials):
        traces, checks = [], []
        for refinement in (1, 2):
            folder = output / f'case_{index}_refinement_{refinement}'
            folder.mkdir()
            (folder / 'ad8410a.cir').symlink_to('../ad8410a.cir')
            (folder / '.spiceinit').write_text('set ngbehavior=ltpsa\n')
            (folder / 'test.cir').write_text(vendor_test_netlist(case['bus_high_V'], current, command, refinement))
            process = subprocess.run([executable, '-b', 'test.cir'], cwd=folder,
                capture_output=True, text=True)
            (folder / 'ngspice.log').write_text(process.stdout + process.stderr)
            process.check_returncode()
            if 'error' in process.stderr.lower():
                raise ValueError(f'ngspice reported an error; inspect {folder}')
            dc = np.loadtxt(folder / 'dc.dat', skiprows=1)
            gain = next(row[1] for row in Fixed.electronics_readout_specs if row[0] == 'AD8410A')
            dc_error = (dc[:, 1] - Fixed.electronics_current_reference - gain * dc[:, 0]) / (
                gain * Fixed.electronics_readout_trial_shunt)
            trace = np.loadtxt(folder / 'transient.dat', skiprows=1)
            period = 1 / Fixed.driver_pwm_frequency
            end = Fixed.electronics_spice_cycles * period
            times = np.linspace(end - period, end, Fixed.electronics_spice_steps_per_cycle + 1)
            errors = np.interp(times, trace[:, 0], trace[:, 2]) - current
            selected = trace[:, 0] >= end - period
            checks.append(dict(refinement=refinement, max_dc_current_error_A=float(np.max(np.abs(dc_error))),
                last_period_peak_readout_error_A=float(np.max(np.abs(trace[selected, 2] - current))),
                last_period_rms_readout_error_A=float(np.sqrt(np.trapezoid(errors**2, times) / period))))
            traces.append(errors)
        difference = float(np.max(np.abs(traces[0] - traces[1])))
        rows.append(dict(command_V=command, imposed_current_A=current, checks=checks,
            refinement_difference_A=difference,
            refinement_pass=difference <= Fixed.electronics_spice_current_tolerance))
    report = dict(status='macromodel_diagnostic_not_hardware_qualification',
        source_sha256=fingerprints, vendor_sha256=hashlib.sha256(content).hexdigest(),
        vendor_url='https://www.analog.com/media/en/simulation-models/spice-models/ad8410a.cir',
        ngspice_version=subprocess.run([executable, '--version'], capture_output=True, text=True, check=True).stdout,
        compatibility='ngspice ltpsa; unchanged manufacturer model',
        bus_V=case['bus_high_V'], switching_edge_s=Fixed.driver_switching_time,
        trials=rows, cost=adoption_cost_screen(), hardware_qualified=False,
        limitations=[
            'Vendor model was tested by its author in LTspice; these ngspice checks do not establish cross-simulator equivalence.',
            'Vendor header limits common-mode step response to symmetric responses and a 10 mV peak floor; it cannot establish the actual residual at our required accuracy.',
            'Temperature drift, distortion, overload recovery, PSRR and supply/load parameter variation are explicitly omitted.',
            'Noise flatband is limited to 100 kHz by the vendor; ordinary transient runs here do not inject its small-signal noise.',
            'Ideal imposed differential voltage and finite common-mode edges isolate amplifier behaviour; no physical shunt, coil, filter, ADC, driver parasitics or regulation loop is simulated.',
            'DC sweep uses zero common-mode voltage. Transient cases cover a few duties and constant current extremes at the upper supply, not all operating conditions.',
            'Continuous waveform peak/RMS error is not sampled-current error, random noise, or a settled-window acceptance test.'])
    (output / 'summary.json').write_text(json.dumps(report, indent=Fixed.report_precision) + '\n')
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Screen current-readout timing, range, quantization and noise without claiming circuit qualification.')
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--vendor-model', type=Path)
    parser.add_argument('--ngspice', default='ngspice')
    arguments = parser.parse_args()
    if arguments.vendor_model:
        run_vendor_model(arguments.output, arguments.vendor_model, arguments.ngspice)
    else:
        export_screen(arguments.output)
