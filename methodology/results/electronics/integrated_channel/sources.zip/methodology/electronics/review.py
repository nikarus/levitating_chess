import argparse
import hashlib
import json
from pathlib import Path
import subprocess
from xml.etree import ElementTree
from zipfile import ZIP_DEFLATED, ZipFile

import model
from model import Inputs, Fixed
from methodology import prototype_coils, source_fingerprints


def load_footprint(footprint_library, identifier):
    import pcbnew

    library, name = identifier.split(':')
    filename = footprint_library / f'{library}.pretty' / f'{name}.kicad_mod'
    footprint = pcbnew.FootprintLoad(str(filename.parent), name)
    if footprint is None:
        raise ValueError(f'Missing footprint: {filename}')
    footprint.BuildCourtyardCaches()
    courtyard = footprint.GetCourtyard(pcbnew.F_CrtYd)
    if courtyard.OutlineCount() != 1 or courtyard.Area() <= 0:
        raise ValueError(f'Footprint requires a single closed front courtyard: {filename}')
    return footprint, filename


def validate_integrated_channel(netlist):
    connected = {}
    for net in netlist.findall('nets/net'):
        for node in net.findall('node'):
            key = (node.attrib['ref'], node.attrib['pin'])
            if key in connected:
                raise ValueError(f'Pin belongs to multiple nets: {key}')
            connected[key] = net.attrib['name'].removeprefix('/')
    driver_nets = {
        'GND': (1, 3, 10, 13, 20, 35, 36, 37, 38, 40, 44),
        'V_MOTOR': (2, 11, 12, 21), 'VCP': (22,), 'CPH': (23,), 'CPL': (24,),
        'AWAKE': (25,), 'PWM_A_P': (26,), 'PWM_A_N': (27,),
        'PWM_B_P': (28,), 'PWM_B_N': (29,), 'ENABLE_A': (30, 31),
        'ENABLE_B': (32, 33), 'DVDD': (34, 39, 42, 43), 'FAULT_N': (41,),
        'SW_A': (17, 18, 19), 'COIL_A_N': (14, 15, 16),
        'SW_B': (4, 5, 6), 'COIL_B_N': (7, 8, 9),
    }
    expected = {('U1', str(pin)): net for net, pins in driver_nets.items() for pin in pins}
    for channel, amplifier, shunt, bypass in (('A', 'U2', 'R5', 'C10'), ('B', 'U3', 'R6', 'C11')):
        for pin, net in {
            '1': f'COIL_{channel}_P', '2': 'GND', '3': 'VREF_CURRENT', '4': 'GND',
            '5': f'CURRENT_{channel}', '6': 'V_ANALOG', '7': 'VREF_CURRENT', '8': f'SW_{channel}',
        }.items():
            expected[(amplifier, pin)] = net
        expected[(shunt, '1')] = f'SW_{channel}'
        expected[(shunt, '2')] = f'COIL_{channel}_P'
        expected[(bypass, '1')] = 'V_ANALOG'
        expected[(bypass, '2')] = 'GND'
    for reference, nets in {
        'C1': ('V_MOTOR', 'GND'), 'C2': ('V_MOTOR', 'GND'),
        'C3': ('V_MOTOR', 'GND'), 'C4': ('V_MOTOR', 'GND'),
        'C5': ('V_MOTOR', 'GND'), 'C6': ('VCP', 'V_MOTOR'), 'C7': ('CPH', 'CPL'),
        'C8': ('DVDD', 'GND'), 'C9': ('DVDD', 'GND'),
        'R1': ('FAULT_N', 'DVDD'), 'R2': ('AWAKE', 'GND'),
        'R3': ('ENABLE_A', 'GND'), 'R4': ('ENABLE_B', 'GND'),
    }.items():
        expected.update({(reference, str(index)): net for index, net in enumerate(nets, start=1)})
    if connected != expected:
        differences = {str(pin): dict(expected=expected.get(pin), actual=connected.get(pin))
                       for pin in expected.keys() | connected.keys() if expected.get(pin) != connected.get(pin)}
        raise ValueError(f'Integrated channel connectivity differs from reviewed DDV circuit: {differences}')
    components = {part.attrib['ref']: part for part in netlist.findall('components/comp')}
    for reference, mpn in (('U1', Fixed.electronics_integrated_driver[0]),
                           ('U2', 'INA241A1IDGKR'), ('U3', 'INA241A1IDGKR')):
        fields = {field.attrib['name']: field.text for field in components[reference].findall('fields/field')}
        if fields['MPN'] != mpn:
            raise ValueError(f'Unreviewed active component: {reference}')
    return dict(passed=True, checked_pins=len(expected),
                scope='DDV pin map, inline shunt polarity, local support and disabled internal chopping; not circuit functionality')


def export_review(schematic, footprint_library, executable, output):
    import pcbnew

    if output.exists():
        raise ValueError('Preserve existing schematic review evidence')
    output.mkdir(parents=True)
    commands = [
        ['sch', 'export', 'netlist', '--format', 'kicadxml', '-o', str(output / 'netlist.xml')],
        ['sch', 'export', 'pdf', '-o', str(output / 'channel.pdf')],
        ['sch', 'export', 'bom', '--fields', 'Reference,Value,MPN,Footprint,${QUANTITY},ModelParameter',
         '--labels', 'References,Value,MPN,Footprint,Quantity,ModelParameter',
         '--group-by', 'MPN,Value,Footprint,ModelParameter', '-o', str(output / 'bom.csv')],
        ['sch', 'erc', '--format', 'json', '-o', str(output / 'erc.json')],
    ]
    logs = []
    for command in commands:
        result = subprocess.run([executable, *command, str(schematic)], capture_output=True, text=True, check=True)
        logs.append(dict(command=command, stdout=result.stdout, stderr=result.stderr))
    (output / 'export_log.json').write_text(json.dumps(logs, indent=Fixed.report_precision) + '\n')
    netlist = ElementTree.parse(output / 'netlist.xml').getroot()
    connectivity = validate_integrated_channel(netlist)
    components = []
    footprint_paths = set()
    channel_count = 0
    for component in netlist.findall('components/comp'):
        fields = {field.attrib['name']: field.text for field in component.findall('fields/field')}
        if not fields.get('MPN'):
            raise ValueError(f"Missing part identity: {component.attrib['ref']}")
        if fields.get('CoilChannels'):
            channel_count += int(fields['CoilChannels'])
        parameter = fields.get('ModelParameter')
        value = component.findtext('value')
        if parameter and float(value) != getattr(Fixed, parameter):
            raise ValueError(f"Stale model-derived component value: {component.attrib['ref']}")
        footprint, filename = load_footprint(footprint_library, component.findtext('footprint'))
        footprint_paths.add(filename)
        courtyard = footprint.GetCourtyard(pcbnew.F_CrtYd)
        components.append(dict(reference=component.attrib['ref'], mpn=fields['MPN'], value=value,
            model_parameter=parameter, footprint=component.findtext('footprint'),
            courtyard_area_mm2=courtyard.Area() / 1e12))
    if channel_count != Fixed.electronics_integrated_driver[2]:
        raise ValueError('Schematic channel count differs from the reviewed integrated driver')
    _, coil, _ = prototype_coils.prototype_geometry(Inputs.cad_coil_layout)
    pitch_area = (coil.outer_width + Inputs.prototype_coil_spacing) * (coil.outer_length + Inputs.prototype_coil_spacing)
    courtyard_area = sum(part['courtyard_area_mm2'] for part in components)
    erc = json.loads((output / 'erc.json').read_text())
    violations = [violation for sheet in erc['sheets'] for violation in sheet['violations']]
    report = dict(status='draft_channel_incomplete_no_manufacturing_release',
        source_sha256=source_fingerprints(__file__, model.__file__, schematic, schematic.parent / 'FlyingChess.kicad_sym',
            schematic.with_suffix('.kicad_pro'), schematic.parent / 'fp-lib-table', schematic.parent / 'sym-lib-table',
            prototype_coils.__file__),
        footprint_sha256={str(path.relative_to(footprint_library)): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sorted(footprint_paths)},
        component_count=len(components), coil_channel_count=channel_count, components=components,
        connectivity=connectivity,
        placement_bound=dict(courtyard_sum_mm2=courtyard_area,
            courtyard_per_channel_mm2=courtyard_area / channel_count, coil_pitch_area_mm2=pitch_area,
            double_sided_area_per_coil_mm2=2 * pitch_area,
            minimum_area_ratio_to_double_sided=courtyard_area / (channel_count * 2 * pitch_area),
            fits_even_before_routing=courtyard_area <= channel_count * 2 * pitch_area),
        erc=dict(errors=sum(row['severity'] == 'error' for row in violations),
            warnings=sum(row['severity'] == 'warning' for row in violations),
            passed=not violations),
        complete_hardware_baseline=False,
        limitations=[
            'Courtyard sum is an optimistic placement lower bound for this candidate and these footprints; no routing, shared circuit or thermal-spreading area is included.',
            'Both PCB faces are credited as fully usable, despite winding terminations and mechanical constraints.',
            'This is an integrated dual-channel circuit; the earlier placement predates its complete local support and must not be treated as placement of this netlist.',
            'Power generation/regeneration, ADC, buffered reference, independent overcurrent shutdown, control and interconnect are not implemented.',
            'External named nets are interface contracts, not completed shared circuitry. No power flags or ERC exclusions hide missing sources.',
            'DDV pin mapping is checked; the library footprint remains provisional pending manufacturer land-pattern qualification.',
            'Internal current chopping is disabled for external precision regulation. Internal short-circuit protection does not establish the coil-safe current limit.',
            'No compatible driver SPICE model has been established. Connectivity is not functional simulation.',
            'INA241A PWM rejection is advertised through 125 kHz, below the configured carrier; its vendor macro-model explicitly omits enhanced PWM rejection. Readout at the intended switching conditions remains unqualified.',
            'No component price, production BOM, thermal pass or hardware equivalence to the averaged simulator is claimed.'])
    with ZipFile(output / 'sources.zip', 'x', compression=ZIP_DEFLATED) as archive:
        for name in report['source_sha256']:
            archive.write(name, name)
        for path in sorted(footprint_paths):
            archive.write(path, str(Path('kicad_footprints') / path.relative_to(footprint_library)))
    (output / 'summary.json').write_text(json.dumps(report, indent=Fixed.report_precision) + '\n')
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Export a KiCad channel review and footprint-area lower bound.')
    parser.add_argument('--schematic', type=Path, required=True)
    parser.add_argument('--footprints', type=Path, required=True)
    parser.add_argument('--kicad-cli', required=True)
    parser.add_argument('--output', type=Path, required=True)
    arguments = parser.parse_args()
    export_review(arguments.schematic, arguments.footprints, arguments.kicad_cli, arguments.output)
