import argparse
import json
import math
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

import numpy as np

import model
from model import Fixed
from methodology import electrical, source_fingerprints
from methodology.electronics import power_stage


def edge_intervals(mean_voltage, bus_voltage, frequency):
    if not np.isfinite(frequency) or frequency <= 0:
        raise ValueError('Carrier frequency must be positive and finite')
    duties = power_stage.unipolar_leg_duties(mean_voltage, bus_voltage)
    if any(duty in (0., 1.) for duty in duties):
        raise ValueError('Static bridge legs have no periodic edge-spacing measurement')
    return [[duty / frequency, (1 - duty) / frequency] for duty in duties]


def readout_metrics(gain, shunt, input_noise_density, supply_current):
    if not np.isfinite([gain, shunt, input_noise_density, supply_current]).all() or min(
            gain, shunt, input_noise_density, supply_current) <= 0:
        raise ValueError('Readout parameters must be positive and finite')
    sensitivity = gain * shunt
    excursion = Fixed.driver_peak_current * sensitivity
    rails = [Fixed.electronics_current_reference - excursion,
             Fixed.electronics_current_reference + excursion]
    max_enbw = (Fixed.current_feedback_noise * shunt / input_noise_density) ** 2
    return dict(gain_V_per_V=gain, shunt_ohm=shunt, sensitivity_V_per_A=sensitivity,
        nominal_output_range_V=rails,
        ideal_supply_rail_check=0 < rails[0] and rails[1] < Fixed.electronics_analog_supply,
        peak_shunt_loss_W=Fixed.driver_peak_current ** 2 * shunt,
        amplifier_quiescent_upper_W=Fixed.electronics_analog_supply * supply_current,
        full_supply_adc_quantum_A=Fixed.electronics_analog_supply / sensitivity / 2 ** Fixed.current_feedback_bits,
        minimum_ideal_full_supply_adc_bits=math.ceil(math.log2(
            Fixed.electronics_analog_supply / sensitivity / electrical.current_quantum())),
        typical_white_noise_only_max_ENBW_Hz=max_enbw,
        corresponding_single_pole_cutoff_Hz=max_enbw * 2 / np.pi,
        total_readout_qualified=False)


def screen():
    case = next(row for row in power_stage.topology_cases()
                if row['topology'] == 'unipolar_full_bridge' and row['ripple_pass'] and row['voltage_headroom_pass'])
    limit = case['terminal_voltage_limit_V']
    samples = []
    for bus in (case['bus_low_V'], case['bus_nominal_V'], case['bus_high_V']):
        for voltage in np.linspace(-limit, limit, Fixed.electronics_pwm_screen_points):
            intervals = edge_intervals(float(voltage), bus, Fixed.driver_pwm_frequency)
            shortest = min(min(leg) for leg in intervals)
            samples.append(dict(mean_voltage_V=float(voltage), bus_V=bus,
                shortest_common_mode_edge_interval_s=shortest,
                ina241_documented_edge_spacing_met=shortest >= Fixed.electronics_ina241_edge_spacing))
    candidates = []
    for name, gain, noise, current in Fixed.electronics_readout_specs:
        shunts = (Fixed.current_sense_resistance,) if name == 'INA241A1' else (
            Fixed.current_sense_resistance, Fixed.electronics_readout_trial_shunt)
        for shunt in shunts:
            row = dict(name=name, **readout_metrics(gain, shunt, noise, current))
            if name == 'MAX49925':
                row['within_published_gain_error_test_excursion'] = (
                    Fixed.driver_peak_current * gain * shunt <= Fixed.electronics_max49925_gain_test_excursion)
            candidates.append(row)
    return dict(status='analytical_candidate_screen_not_component_qualification',
        required_current_quantum_A=electrical.current_quantum(),
        required_current_noise_rms_A=Fixed.current_feedback_noise,
        pwm_carrier_Hz=Fixed.driver_pwm_frequency,
        shortest_interval_case=min(samples, key=lambda row: row['shortest_common_mode_edge_interval_s']),
        ina241_documented_edge_spacing_covers_command_envelope=all(
            row['ina241_documented_edge_spacing_met'] for row in samples),
        ina241_edge_spacing_voltage_interval_V=[
            -case['bus_low_V'] * (1 - 2 * Fixed.driver_pwm_frequency * Fixed.electronics_ina241_edge_spacing),
            case['bus_low_V'] * (1 - 2 * Fixed.driver_pwm_frequency * Fixed.electronics_ina241_edge_spacing)],
        samples=samples, candidates=candidates,
        datasheets={
            'INA241A1': 'https://www.ti.com/lit/ds/symlink/ina241a.pdf',
            'AD8410A': 'https://www.analog.com/media/en/technical-documentation/data-sheets/ad8410a.pdf',
            'MAX49925': 'https://www.analog.com/media/en/technical-documentation/data-sheets/max49925.pdf'},
        limitations=[
            'Ideal centered unipolar leg timing; finite edge times, dead time, parasitics and movement are not simulated here.',
            'Meeting an edge-spacing condition does not establish sampling accuracy; violating it removes that documented rejection condition, not all amplifier functionality.',
            'Noise uses typical spot input-noise densities as white-noise estimates and assigns the entire existing RMS budget to the amplifier. Flicker, spectral variation, reference, ADC, shunt noise, aliasing and PWM residue require separate analysis.',
            'The illustrative single-pole noise bandwidth is not a selected filter or a verified delay budget.',
            'ADC bits assume a full-supply input span and ideal quantization. A narrower converter range changes this calculation; bits alone do not establish accuracy or noise.',
            'Output checks only screen ideal supply rails; actual output swing, gain/offset variation and ADC loading remain unqualified.',
            'Shunt alternatives are screening cases only; no schematic, controller or flight setting has been changed.',
            'INA241A vendor macro-model omits enhanced PWM rejection. This screen does not execute or qualify manufacturer circuit models.'])


def export_screen(output):
    if output.exists():
        raise ValueError('Preserve existing readout evidence')
    result = screen()
    result['source_sha256'] = source_fingerprints(__file__, model.__file__, electrical.__file__,
        power_stage.__file__, power_stage.design.__file__, power_stage.prototype_coils.__file__,
        power_stage.qualification.__file__)
    output.mkdir(parents=True)
    with ZipFile(output / 'sources.zip', 'x', compression=ZIP_DEFLATED) as archive:
        for filename in result['source_sha256']:
            archive.write(filename, filename)
    (output / 'summary.json').write_text(json.dumps(result, indent=Fixed.report_precision) + '\n')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Screen current-readout timing, range, quantization and noise without claiming circuit qualification.')
    parser.add_argument('--output', type=Path, required=True)
    export_screen(parser.parse_args().output)
