import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

import numpy as np
from scipy.linalg import expm
from scipy.optimize import brentq

import model
from model import Inputs, Fixed
from methodology import coil_layouts, source_fingerprints
from methodology.electronics import current_loop, power_stage


class SharedMotorBus:
    def __init__(self,source_voltage,bulk_count):
        _,capacitance,tolerance,_,impedance=Fixed.electronics_shared_bulk_candidate
        if source_voltage<=0 or not isinstance(bulk_count,int) or bulk_count<=0:
            raise ValueError('A positive motor source and explicit bulk count are required')
        self.source_voltage=source_voltage
        self.capacitance=bulk_count*capacitance*(1-tolerance)
        self.capacitor_resistance=impedance/bulk_count
        self.feed_resistance=Fixed.electronics_shared_feed_resistance
        self.current_limit=Fixed.electronics_shared_source_current

    def operating_point(self,capacitor_voltage,load_current):
        source_current=np.clip((self.source_voltage-capacitor_voltage+self.capacitor_resistance*load_current)/
            (self.feed_resistance+self.capacitor_resistance),0.,self.current_limit)
        capacitor_current=source_current-load_current
        voltage=capacitor_voltage+self.capacitor_resistance*capacitor_current
        return dict(voltage_V=float(voltage),source_current_A=float(source_current),
            capacitor_current_A=float(capacitor_current),capacitor_rate_V_s=float(capacitor_current/self.capacitance),
            distribution_loss_W=float(self.feed_resistance*source_current**2),
            current_limit_loss_W=float(max(0.,(self.source_voltage-voltage-self.feed_resistance*source_current)*source_current)),
            capacitor_loss_W=float(self.capacitor_resistance*capacitor_current**2))

    def voltage_rate(self,capacitor_voltage,load_current,capacitor_rate,load_rate):
        source=self.operating_point(capacitor_voltage,load_current)['source_current_A']
        source_rate=(-capacitor_rate+self.capacitor_resistance*load_rate)/(self.feed_resistance+self.capacitor_resistance) if 0<source<self.current_limit else 0.
        return capacitor_rate+self.capacitor_resistance*(source_rate-load_rate)


def absorbed_energy_voltage(capacitance, initial_voltage, energy):
    if capacitance<=0 or initial_voltage<0 or energy<0:
        raise ValueError('Energy absorption requires positive capacitance and nonnegative voltage and energy')
    return float(np.sqrt(initial_voltage**2+2*energy/capacitance))


def required_absorption_capacitance(initial_voltage, maximum_voltage, energy):
    if energy<0 or initial_voltage<0 or maximum_voltage<=initial_voltage:
        raise ValueError('Energy absorption requires a positive voltage headroom')
    return 2*energy/(maximum_voltage**2-initial_voltage**2)


def disabled_return(channels, current, inductance, resistance, capacitance, voltage, diode_voltage=0., capacitor_resistance=0.):
    if not isinstance(channels,int) or channels<=0 or min(inductance,capacitance,voltage)<=0 or min(current,resistance,diode_voltage,capacitor_resistance)<0:
        raise ValueError('Disabled return requires identical nonnegative branch currents and positive L, C and bus voltage')
    matrix=np.array([[-(resistance+channels*capacitor_resistance)/inductance,-1/inductance],
        [channels/capacitance,0.]])
    initial=np.array([current,voltage+2*diode_voltage])
    def state(time):
        return expm(matrix*time)@initial
    if current==0:
        end=0.
    else:
        bracket=inductance*current/(voltage+2*diode_voltage)
        frequency_squared=channels/(inductance*capacitance)-(matrix[0,0]/2)**2
        if frequency_squared>0:
            bracket=min(bracket,np.pi/(2*np.sqrt(frequency_squared)))
        end=brentq(lambda time:state(time)[0],0.,bracket,xtol=np.spacing(bracket))
    def terminal(time):
        branch,shifted_voltage=state(time)
        return shifted_voltage-2*diode_voltage+channels*capacitor_resistance*branch
    def terminal_rate(time):
        rates=matrix@state(time)
        return rates[1]+channels*capacitor_resistance*rates[0]
    extrema=[0.,end]
    if end>0 and terminal_rate(0.)*terminal_rate(end)<0:
        extrema.append(brentq(terminal_rate,0.,end,xtol=np.spacing(end)))
    final_voltage=float(state(end)[1]-2*diode_voltage)
    initial_energy=channels*inductance*current**2/2
    stored=capacitance*(final_voltage**2-voltage**2)/2
    return dict(decay_time_s=end,final_capacitor_voltage_V=final_voltage,
        maximum_terminal_voltage_V=float(max(map(terminal,extrema))),
        initial_return_current_A=channels*current,initial_coil_energy_J=initial_energy,
        capacitor_energy_increase_J=stored,dissipated_energy_J=initial_energy-stored,
        lossless_voltage_bound_V=absorbed_energy_voltage(capacitance,voltage,initial_energy))


def regeneration_screen(parts):
    envelope=group_power_envelope(parts)
    nominal=current_loop.nominal_circuit()
    mpn,capacitance,tolerance,rating,impedance=Fixed.electronics_shared_bulk_candidate
    trials=[]
    for count in Fixed.electronics_shared_bulk_counts:
        effective=count*capacitance*(1-tolerance) if count else envelope['local_nominal_motor_capacitance_F']
        for initial_voltage in (nominal['bus_nominal'],nominal['bus_high']):
            for capacitor_resistance in ((0.,impedance/count) if count else (0.,)):
                result=disabled_return(envelope['channels'],Fixed.driver_peak_current,envelope['inductance_upper_H'],
                    nominal['coil_resistance']+Fixed.electronics_readout_trial_shunt/2+2*Fixed.electronics_bridge_diode[1],
                    effective,initial_voltage,Fixed.electronics_bridge_diode[0],capacitor_resistance)
                trials.append(dict(bulk_count=count,bulk_MPN=mpn if count else None,
                    assumed_capacitance_F=effective,initial_voltage_V=initial_voltage,
                    assumed_capacitor_resistance_ohm=capacitor_resistance,**result,
                    within_operating_voltage=result['maximum_terminal_voltage_V']<=nominal['bus_high']))
    return dict(trials=trials,bulk_voltage_rating_V=rating,
        status='piecewise_exact_disabled_inductive_return_screen_not_supply_qualification',
        limitations=[
            'Identical stationary branches begin at the physical peak and maximum screened inductance. Both current polarities return energy through two body diodes. The branch is disconnected at its first zero-current crossing, preventing unphysical reverse current.',
            'The matrix exponential solves the conducting RLC interval without time stepping. Coil/shunt/diode resistance and capacitor resistance dissipate energy; the independent lossless bound remains applicable.',
            'The source is disconnected and cannot absorb energy. Motion-induced voltage, externally injected energy, wiring inductance, source dynamics, clamp action and switching-node ringing are absent.',
            'Bulk cases use minimum nameplate capacitance and give no credit for local ceramics. The no-bulk case uses nominal local capacitance. Aging, temperature and frequency dependence still need qualification.',
            'The nonzero capacitor-resistance case uses the published 100 kHz/20 C impedance as an exploratory constant resistance, not a broadband or cold-temperature ESR bound. Neither capacitor pulse-current capability nor lifetime is qualified.',
            'A voltage pass for this isolated event does not qualify a complete supply. An initial bus at the operating ceiling leaves no regenerative headroom; source tolerance and an absorbing clamp remain necessary design decisions.'])


def group_power_envelope(parts):
    counts=Counter(row['mpn'] for row in parts)
    channels=counts['INA181A1IDBVR']
    drivers=counts[Fixed.electronics_integrated_driver[0]]
    converters=counts[Fixed.electronics_acquisition_sar[0]]
    if channels!=Fixed.electronics_acquisition_sar[2] or drivers*Fixed.electronics_integrated_driver[2]!=channels or converters!=1:
        raise ValueError('Supply screen requires the complete reviewed independent-coil group')
    nominal=current_loop.nominal_circuit()
    inductance=nominal['inductance']*max(Fixed.qualification_inductance_factors)
    energy=channels*inductance*Fixed.driver_peak_current**2/2
    capacitors=[row for row in parts if row['model_parameter']=='electronics_channel_bus_capacitance']
    capacitance=sum(float(row['value']) for row in capacitors)
    analog_voltage=Fixed.electronics_analog_supply
    amplifier_current=next(row[3] for row in Fixed.electronics_readout_specs if row[0]=='INA181A1')
    fixed_analog_current=channels*amplifier_current+counts['REF5025IDR']*Fixed.electronics_reference_quiescent_current
    typical_awake,maximum_awake,sleep_current=Fixed.electronics_drv8962_supply_currents
    conversion,standby,power_down=Fixed.electronics_sar_analog_currents
    modes={name:dict(driver_VM_W=drivers*nominal['bus_nominal']*driver_current,
        analog_5V_W=analog_voltage*(fixed_analog_current+converters*adc_current))
        for name,driver_current,adc_current in (
            ('all_awake_converting',maximum_awake,conversion),
            ('drivers_asleep_ADC_standby',sleep_current,standby),
            ('drivers_asleep_ADC_power_down',sleep_current,power_down))}
    for mode in modes.values():
        mode['partial_no_load_W']=sum(mode.values())
    board=power_stage.design.BoardGeometry()
    array=power_stage.prototype_coils.prototype_array(Inputs.cad_coil_layout)
    channel_count=board.motor_area/1e6*coil_layouts.channel_density(array,'independent')
    return dict(channels=channels,driver_packages=drivers,converter_packages=converters,
        operating_bus_V=nominal['bus_nominal'],operating_bus_ceiling_V=nominal['bus_high'],
        inductance_upper_H=inductance,simultaneous_disabled_coil_energy_bound_J=energy,
        local_nominal_motor_capacitance_F=capacitance,
        lossless_bus_voltage_after_disable_from_nominal_V=absorbed_energy_voltage(capacitance,nominal['bus_nominal'],energy),
        minimum_effective_capacitance_from_nominal_F=required_absorption_capacitance(nominal['bus_nominal'],nominal['bus_high'],energy),
        local_nominal_capacitance_passes_operating_envelope=absorbed_energy_voltage(capacitance,nominal['bus_nominal'],energy)<=nominal['bus_high'],
        driver_typical_awake_no_load_W=drivers*nominal['bus_nominal']*typical_awake,
        no_load_modes=modes,area_equivalent_installed_channels=channel_count,
        area_equivalent_whole_board_partial_no_load_W={name:values['partial_no_load_W']*channel_count/channels for name,values in modes.items()},
        wake_waits_s=dict(driver=Fixed.electronics_drv8962_wake_time,driver_cold_start=Fixed.electronics_drv8962_turn_on_time,
            ADC_from_standby=Fixed.electronics_sar_wake_times[0],ADC_from_power_down=Fixed.electronics_sar_wake_times[1]),
        continuous_all_channel_coil_copper_loss_W=channels*nominal['coil_resistance']*Fixed.driver_channel_current**2)


def run(review,output):
    if output.exists():
        raise ValueError('Preserve existing supply evidence')
    schematic=json.loads(review.read_text())
    for filename,digest in schematic['source_sha256'].items():
        if hashlib.sha256(Path(filename).read_bytes()).hexdigest()!=digest:
            raise ValueError(f'Schematic review source changed: {filename}')
    report=dict(status='schematic_based_partial_power_and_inductive_return_envelope',
        **group_power_envelope(schematic['components']),
        disabled_return=regeneration_screen(schematic['components']),
        source_sha256=source_fingerprints(__file__,model.__file__,current_loop.__file__,power_stage.__file__,
            power_stage.design.__file__,power_stage.prototype_coils.__file__,coil_layouts.__file__),
        input_sha256={str(review):hashlib.sha256(review.read_bytes()).hexdigest()},
        complete_supply_or_thermal_qualification=False,
        sources=['https://www.ti.com/lit/ds/symlink/drv8962.pdf','https://www.ti.com/lit/ds/symlink/ads8698.pdf',
            'https://www.ti.com/lit/ds/symlink/ina181.pdf','https://www.ti.com/lit/ds/symlink/ref50.pdf',
            'https://na.industrial.panasonic.com/products/capacitors/aluminum-electrolytic-capacitors/aluminum-electrolytic-capacitors-radial-lead-type/series/83367/model/83735'],
        limitations=[
            'Worst-case stored coil energy at the existing physical peak and inductance upper sensitivity bound, returned without dissipation or source absorption. Lossless energy conservation bounds this isolated inductive return, not externally supplied mechanical energy.',
            'Local capacitance is nameplate capacitance, before DC bias, tolerance, temperature, ESR, ESL and distribution inductance. The calculation does not qualify a bulk capacitor or clamp circuit.',
            'A capacitor alone cannot keep the bus below its operating ceiling if it starts at that ceiling. An explicit supply headroom and/or absorbing clamp is required; no supply is assumed to sink current.',
            'No-load modes sum specified maximum driver VM, converter AVDD, amplifier and reference supply currents at their stated voltages. MCU, digital I/O, reference output load, watchdog, Hall sensing, other logic, conversion losses and output switching are excluded. These are partial scenarios, not whole-board upper bounds.',
            'All-powered installed-channel scaling is area-equivalent, before edge and module rounding. Selective sleep and wake sequencing are required design functions, not implemented by this inventory calculation.',
            'The all-channel copper-loss value is a continuous group stress envelope at cold resistance, not an actual chess workload. Full-board workload, hot resistance, driver losses, motion regeneration, bus wiring and thermal paths remain unresolved.'])
    output.mkdir(parents=True)
    with ZipFile(output/'sources.zip','x',compression=ZIP_DEFLATED) as archive:
        for name in report['source_sha256']:
            archive.write(name,name)
        archive.write(review,str(Path('inputs')/review.name))
        archive.write(review.with_name('sources.zip'),'inputs/schematic_sources.zip')
    (output/'summary.json').write_text(json.dumps(report,indent=Fixed.report_precision)+'\n')
    return report


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--review',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    arguments=parser.parse_args()
    print(json.dumps(run(arguments.review,arguments.output),indent=Fixed.report_precision))
