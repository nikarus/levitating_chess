import argparse
import json
from pathlib import Path
import shutil
import subprocess
from zipfile import ZIP_DEFLATED, ZipFile

import numpy as np

import model
from model import Inputs, Fixed
from methodology import design, prototype_coils, qualification, source_fingerprints


def periodic_cycle(resistance, inductance, low_voltage, high_voltage, duty, frequency, back_emf=0.):
    if resistance <= 0 or inductance <= 0 or frequency <= 0 or not 0 <= duty <= 1 or low_voltage >= high_voltage:
        raise ValueError('Invalid independent RL switching cycle')
    period = 1 / frequency
    on_duration, off_duration = duty * period, (1 - duty) * period
    after_on = qualification.rl_step(0., high_voltage, back_emf, resistance, inductance, on_duration)
    after_off = qualification.rl_step(after_on, low_voltage, back_emf, resistance, inductance, off_duration)
    low_current = after_off / -np.expm1(-resistance * period / inductance)
    high_current = qualification.rl_step(low_current, high_voltage, back_emf, resistance, inductance, on_duration)
    mean = (duty * high_voltage + (1 - duty) * low_voltage - back_emf) / resistance
    return dict(low_A=float(low_current), high_A=float(high_current), mean_A=float(mean),
        peak_deviation_A=float(max(abs(low_current - mean), abs(high_current - mean))))


def topology_cases():
    _, coil, winding = prototype_coils.prototype_geometry(Inputs.cad_coil_layout)
    inductance = design.winding_inductance(coil, winding) * min(Fixed.qualification_inductance_factors)
    voltage_limit = Inputs.selected_bus_voltage * Fixed.coil_bus_voltage_fraction * Fixed.usable_bus_voltage_fraction
    candidates = [('split_rail_half_bridge', Inputs.selected_bus_voltage)]
    candidates.extend(('unipolar_full_bridge', voltage) for voltage in Inputs.electronics_full_bridge_buses)
    cases = []
    for topology, bus in candidates:
        upper_bus = bus * (1 + Fixed.electronics_supply_tolerance)
        lower_bus = bus * (1 - Fixed.electronics_supply_tolerance)
        frequency = Fixed.driver_pwm_frequency * (2 if topology == 'unipolar_full_bridge' else 1)
        low_voltage = -upper_bus / 2 if topology == 'split_rail_half_bridge' else 0.
        high_voltage = upper_bus / 2 if topology == 'split_rail_half_bridge' else upper_bus
        available = lower_bus * Fixed.usable_bus_voltage_fraction * (0.5 if topology == 'split_rail_half_bridge' else 1.)
        samples = []
        for mean_voltage in np.linspace(0., voltage_limit, Fixed.electronics_pwm_screen_points):
            duty = (mean_voltage - low_voltage) / (high_voltage - low_voltage)
            cycle = periodic_cycle(winding.resistance, inductance, low_voltage, high_voltage, duty, frequency)
            samples.append(dict(mean_voltage_V=float(mean_voltage), duty=float(duty), **cycle))
        worst = max(samples, key=lambda row: row['peak_deviation_A'])
        bound = design.split_rail_ripple_peak(winding.resistance, inductance, (high_voltage - low_voltage) / 2, frequency)
        cases.append(dict(topology=topology, bus_nominal_V=bus, bus_high_V=upper_bus, bus_low_V=lower_bus,
            terminal_voltage_limit_V=voltage_limit, guaranteed_usable_voltage_V=available,
            voltage_headroom_pass=available >= voltage_limit,
            coil_R_ohm=winding.resistance, minimum_coil_L_H=inductance,
            switching_levels_V=[low_voltage, high_voltage], ripple_frequency_Hz=frequency,
            per_leg_carrier_Hz=Fixed.driver_pwm_frequency,
            worst=worst, samples=samples, all_duty_ripple_bound_A=bound,
            ripple_pass=bound <= Fixed.driver_max_ripple_current,
            conservative_switch_peak_A=Fixed.driver_channel_current + bound,
            switch_peak_pass=Fixed.driver_channel_current + bound <= Fixed.driver_peak_current))
    return cases


def spice_reference(case, output, executable, refinement):
    period = 1 / case['ripple_frequency_Hz']
    edge = period * Fixed.electronics_spice_edge_fraction
    high_duration = case['worst']['duty'] * period
    if not edge < high_duration < period - edge:
        raise ValueError('SPICE pulse requires a non-degenerate duty cycle')
    step = period / (Fixed.electronics_spice_steps_per_cycle * refinement)
    stop = Fixed.electronics_spice_cycles * period
    name = f"{case['topology']}_{case['bus_nominal_V']:g}V_{refinement}"
    low, high = case['switching_levels_V']
    initial = case['worst']['low_A']
    supplies = f'Vdrive drive 0 PULSE({low:.17g} {high:.17g} 0 {edge:.17g} {edge:.17g} {high_duration-edge:.17g} {period:.17g})'
    return_node = '0'
    if case['topology'] == 'unipolar_full_bridge':
        carrier_period = 2 * period
        duty = case['worst']['duty']
        initial = qualification.rl_step(case['worst']['high_A'], low, 0., case['coil_R_ohm'],
            case['minimum_coil_L_H'], (1 - duty) * period / 2)
        supplies = '\n'.join(
            f'Vleg{leg} {node} 0 PULSE(0 {high:.17g} {(1-leg_duty)*carrier_period/2:.17g} '
            f'{edge:.17g} {edge:.17g} {leg_duty*carrier_period-edge:.17g} {carrier_period:.17g})'
            for leg, node, leg_duty in (('A', 'drive', (1+duty)/2), ('B', 'return', (1-duty)/2)))
        return_node = 'return'
    voltage_expression = 'v(drive)' if return_node == '0' else 'v(drive)-v(return)'
    circuit = f"""Independent periodic RL reference; ideal differential drive, not a transistor model
{supplies}
Rcoil drive winding {case['coil_R_ohm']:.17g}
Lcoil winding {return_node} {case['minimum_coil_L_H']:.17g} IC={initial:.17g}
.options reltol={Fixed.electronics_spice_relative_tolerance:.17g} abstol={Fixed.electronics_spice_absolute_tolerance:.17g}
.control
set wr_singlescale
set wr_vecnames
set numdgt=17
tran {step:.17g} {stop:.17g} 0 {step:.17g} uic
let differential_voltage = {voltage_expression}
wrdata {name}.dat i(Lcoil) differential_voltage
quit
.endc
.end
"""
    netlist = output / f'{name}.cir'
    netlist.write_text(circuit)
    result = subprocess.run([executable, '-b', netlist.name], cwd=output, capture_output=True, text=True, check=True)
    (output / f'{name}.log').write_text(result.stdout + result.stderr)
    if 'error' in result.stderr.lower():
        raise ValueError('ngspice reported an error; inspect the saved log')
    waveform = np.loadtxt(output / f'{name}.dat', skiprows=1)
    start = stop - period
    selected = (waveform[:, 0] > start) & (waveform[:, 0] < stop)
    times = np.r_[start, waveform[selected, 0], stop]
    currents = np.interp(times, waveform[:, 0], waveform[:, 1])
    mean = float(np.trapezoid(currents, times) / period)
    peak = float(np.max(np.abs(currents - mean)))
    analytic = case['worst']
    deviation = max(abs(mean - analytic['mean_A']), abs(peak - analytic['peak_deviation_A']))
    return dict(netlist=netlist.name, refinement=refinement, mean_A=mean,
        peak_deviation_A=peak, rms_A=float(np.sqrt(np.trapezoid(currents ** 2, times) / period)),
        maximum_analytic_difference_A=deviation, passed=deviation <= Fixed.electronics_spice_current_tolerance)


def run(output, executable):
    if output.exists():
        raise ValueError('Preserve existing power-stage evidence')
    executable = str(Path(shutil.which(executable)).resolve())
    cases = topology_cases()
    output.mkdir(parents=True)
    fingerprints = source_fingerprints(__file__, model.__file__, prototype_coils.__file__, design.__file__, qualification.__file__)
    with ZipFile(output / 'sources.zip', 'x', compression=ZIP_DEFLATED) as archive:
        for filename in fingerprints:
            archive.write(filename, filename)
    for case in cases:
        checks = [spice_reference(case, output, executable, refinement) for refinement in (1, 2)]
        difference = max(abs(checks[0][key] - checks[1][key]) for key in ('mean_A', 'peak_deviation_A', 'rms_A'))
        case['independent_spice'] = dict(checks=checks, refinement_difference_A=difference,
            passed=all(check['passed'] for check in checks) and difference <= Fixed.electronics_spice_current_tolerance)
    report = dict(status='ideal_switching_topology_screen_not_complete_circuit_validation',
        source_sha256=fingerprints,
        ngspice_version=subprocess.run([executable, '--version'], capture_output=True, text=True, check=True).stdout,
        bounds=dict(allowed_peak_ripple_A=Fixed.driver_max_ripple_current, peak_device_current_A=Fixed.driver_peak_current,
            cycle_average_current_A=Fixed.driver_channel_current, supply_tolerance_fraction=Fixed.electronics_supply_tolerance),
        cases=cases, independent_spice_passed=all(case['independent_spice']['passed'] for case in cases),
        limitations=[
            'Independent linear RL coil with constant back-EMF during a carrier period; no mutual inductance or magnetic saturation.',
            'Self-inductance remains an unmeasured geometry estimate with the configured lower-bound factor.',
            'Worst ripple is screened over the configured terminal-voltage range; back-EMF shifts mean current without changing periodic ripple.',
            'Full-bridge result requires center-aligned unipolar modulation with two equal differential pulses per carrier cycle; ordinary sign-magnitude PWM has a different ripple frequency.',
            'No MOSFET, gate-driver, dead-time, parasitic, power-distribution or current-acquisition model is included.',
            'A periodic ripple bound does not qualify transient regulation or current reconstruction.',
            'Voltage and current extrema are independent conservative requirements, not an asserted steady physical workload.',
            'No flight simulator settings, source files in the other checkout or original requirements have been changed.'])
    (output / 'summary.json').write_text(json.dumps(report, indent=Fixed.report_precision) + '\n')
    if not report['independent_spice_passed']:
        raise ValueError('Independent SPICE or refinement check failed; retain evidence')
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Screen power-stage ripple against an independent ngspice RL reference.')
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--ngspice', required=True)
    arguments = parser.parse_args()
    run(arguments.output, arguments.ngspice)
